library(ape)
source("/Users/simonjoly/Documents/github/pofadinr/pofad/R/pofadinr.R")
dyn.load("/Users/simonjoly/Documents/github/pofadinr/pofad/src/pofadinr.so")

mat <- data.frame(org=c("sp1","sp2"),alleles=c("A","B","C","D"))

cat("4 2",
    "A     TR",
    "B     DA",
    "C     A-",
    "D     TG",
    file = "exdna.txt", sep = "\n")
ex.dna <- read.dna("exdna.txt", format = "sequential")
as.character(ex.dna)
cat(ex.dna)
pofadinr(ex.dna, model="GENPOFAD",pairwise.deletion = TRUE)
pofadinr(ex.dna, model="GENPOFAD",pairwise.deletion = FALSE)
pofadinr(ex.dna, model="MATCHSTATES",pairwise.deletion = TRUE)
pofadinr(ex.dna, model="MATCHSTATES",pairwise.deletion = FALSE)

source("/Users/simonjoly/Documents/github/pofadinr/pofadinr.R")
dyn.load("/Users/simonjoly/Documents/github/pofadinr/pofadinr.so")
con <- consensusDNA(ex.dna)
as.character(con)

# test consensus.org


mat <- data.frame(org=rep(c("sp1","sp2"),each=2),alleles=c("A","B","C","D"))
cat("4 2",
    "A     TG",
    "B     DA",
    "C     A-",
    "D     TG",
    file = "exdna.txt", sep = "\n")
ex.dna <- read.dna("exdna.txt", format = "sequential")

source("/Users/simonjoly/Documents/github/pofadinr/pofad/R/pofadinr.R")
dyn.load("/Users/simonjoly/Documents/github/pofadinr/pofad/src/pofadinr.so")

as.character(consensus.dna(ex.dna))
as.character(consensus.org(ex.dna,mat))
conseq <- consensus.org(ex.dna,mat)
conseq

cat("4 11",
    "A     TRTACGTTGAC",
    "B     AYTAGTTAGWR",
    "C     AGTAATATGSC",
    "D     ARWGGTADGWT",
    file = "exdna.txt", sep = "\n")
ex.dna <- read.dna("exdna.txt", format = "sequential")
mat <- data.frame(org=rep(c("sp1","sp2"),each=2),alleles=c("A","B","C","D"))

