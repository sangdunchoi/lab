
dist.snp <- function(x, model = "GENPOFAD", variance = FALSE, gamma = FALSE,
                     pairwise.deletion = FALSE, base.freq = NULL,
                     as.matrix = FALSE)
{
  
    MODELS <- c("GENPOFAD", "MATCHSTATES")
    imod <- pmatch(toupper(model), MODELS)
    if (is.na(imod))
        stop(paste("'model' must be one of:",
                   paste("\"", MODELS, "\"", sep = "", collapse = " ")))
    if (variance && imod %in% c(1:2)) {
      warning(paste("computing variance not available for model", model))
      variance <- FALSE
    }
    if (gamma && imod %in% c(1:2)) {
        warning(paste("gamma-correction not available for model", model))
        gamma <- FALSE
    }
    if (is.list(x)) x <- as.matrix(x)
    nms <- dimnames(x)[[1]]
    n <- dim(x)
    s <- n[2]
    n <- n[1]

    BF <- 0

    #if (imod %in% 1:2) pairwise.deletion <- TRUE

    if (!pairwise.deletion) {
        keep <- .C(GlobalDeletionDNA, x, n, s, rep(1L, s))[[4]]
        x <- x[, as.logical(keep)]
        s <- dim(x)[2]
    }
    Ndist <- n*(n - 1)/2
    var <- if (variance) double(Ndist) else 0
    if (!gamma) gamma <- alpha <- 0
    else {
        alpha <- gamma
        gamma <- 1
    }
    d <- .C("pofad", x, as.integer(n), as.integer(s), imod,
            double(Ndist), BF, as.integer(pairwise.deletion),
            as.integer(variance), var, as.integer(gamma),
            as.double(alpha), NAOK = TRUE)
    if (variance) var <- d[[9]]
    d <- d[[5]]
    if (imod == 11) {
        dim(d) <- c(n, n)
        dimnames(d) <- list(nms, nms)
    } else {
        attr(d, "Size") <- n
        attr(d, "Labels") <- nms
        attr(d, "Diag") <- attr(d, "Upper") <- FALSE
        attr(d, "call") <- match.call()
        attr(d, "method") <- model
        class(d) <- "dist"
        if (as.matrix) d <- as.matrix(d)
    }
    if (variance) attr(d, "variance") <- var
    d
}

consensus.dna <- function(x)
{
    # Compute the consensus sequence of the alignment given as a matrix
    # given in DNAbin format

    if (is.list(x)) x <- as.matrix(x)
    n <- dim(x)
    s <- n[2]
    n <- n[1]

    d <- .C("consensusDNA", x, raw(s), as.integer(n), as.integer(s))

    con <- matrix(d[[2]],ncol=s)
    class(con) <- "DNAbin"
    con
}

consensus.org <- function(x, mat)
{
  # Given a DNA alignment in DNAbin format and 
  # a matrix assigning alleles to organisms,
  # the function computes the consensus sequence of all
  # alleles for each organisms
  
  if (is.list(x)) x <- as.matrix(x)
  nms <- dimnames(x)[[1]]
  s <- dim(x)[2]
  
  if(!is.data.frame(mat)) mat <- as.data.frame(mat)
  
  if (!is.factor(mat[,1]) || !is.factor(mat[,2]))
    stop('Only dataframe with factors are accepted (no numeric columns)')
  
  alleles.missing <- mat[!(mat[,2] %in% nms),2]
  if (length(alleles.missing) > 0)
    stop("The following alleles are not found in the DNA matrix\n",
         paste(alleles.missing,collapse="\n"))
  
  #order alleles in data.frame as in alignment
  mat <- mat[match(nms,mat[,2]),]
  
  org <- levels(mat[,1])
  con <- matrix(raw(),nrow=length(org),ncol=s,dimnames=list(org,NULL))
  class(con) <- "DNAbin"
  
  for (i in 1: length(org)) {
    newx <- x[mat[,1]==org[i],]
    d <- .C("consensusDNA", newx, raw(s), as.integer(nrow(newx)), as.integer(s))
    con[i,] <- d[[2]]
  }
  con
}
