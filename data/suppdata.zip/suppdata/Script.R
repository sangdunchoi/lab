#
# Script to replicate the analyses of the paper:
#
# Joly et al. - Pollinator specialization imposes stronger
#     evolutionary constraints on corolla shape
#
# This script was executed with R version 3.2.3
#

# Set working directory - you might have to change this

setwd("~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir")

# Read landmark data -----------------------------------------

# This section has to be done only once. Once done, you can proceed
# to the main script.

library(geomorph)

# Open function read.nts.R
source("utility_functions.R")

# Open .nts file
rawland <- read.nts("landmark_data.nts")

# Save landmarks in R format
save(rawland,file="landmark_data.Rdata")
rm(list = ls())


# Procrustes analysis  --------------------------------------------------

library(geomorph)
library(shapes)
source("utility_functions.R")

# Open landmark data
load("landmark_data.Rdata")

## Landmarks numbers (NOT RUN)
# test<-rawland$landmarks[,,286]
# rownames(test)<-seq(from=1,by=1,length=nrow(test))
# plot(test,type='n');text(test,rownames(test))
# rm(test)

# loading data info and merge into a data.frame
names <- read.table("names.txt", header=TRUE)
dbase <- read.csv("species.csv", sep=";", header=TRUE)
dbase <- dbase[,-c(6:8)]
data <- merge(x=names, y=dbase, by.x="CodeSpecies",
              by.y="CodeSpecies",all.x=TRUE,sort=FALSE) 
data <- data[match(names[,'FileName'],data[,'FileName']),]
rm(dbase)


# Variance analysis of replicated pictures ------------

# Procrustes analysis

# Import the matrix of semi-landmarks
semi<-as.matrix(read.csv2("matrix_semilandmarks.csv",header=TRUE))

# Procrustes analysis (for semi-landmarks)
res.gpa <- gpagen(rawland$landmarks,curves=semi,ProcD=TRUE)

# Procrustes ANOVA

# Convert coordinates to 2D matrix
xx<-two.d.array(res.gpa$coords)
rownames(xx) <- rep(data[,'FileName'],each=2)

# Keep only duplicated pictures for ANOVA
data.subset <- xx[275:298,]

# Variables
flower <- rep(c(1,1,2,2,3,3),times=4)
spe.anova <- factor(rep(data[138:149,'Species'],each=2))

# Hierachical ANOVA
res <- procD.lm(data.subset~spe.anova/flower,iter=999)
(result <- data.frame(variables=c("species","species:flower","residuals","total"),
                     Sum_of_Squares=res$SS,Percent_Variance=round(res$SS/max(res$SS)*100,digits=2)))
# Results
# 99.04 % of the variation between species
#  0.15 % of the variation between picture replicates
#  0.81 % of variation between technical replicates of the same picture.

rm(result,res,spe.anova,flower,data.subset,xx,res.gpa)


# Final Procrustes analysis -------------

# Remove duplicated flowers
landmarks <- rawland$landmarks[,,-c(275:298)]
data <- data[-c(138:149),]

# Procrustes analysis (for semi-landmarks)
res.gpa <- gpagen(landmarks,curves=semi,ProcD=TRUE)
rm(semi)

## Error checking (NOT RUN) -------------------
#
## Look for large distances between replicates of the same flowers
# 
# xx<-two.d.array(res.gpa$coords)
# rownames(xx) <- rep(data[,'FileName'],each=2)
# dist.copy <- numeric(length(data[,'FileName']))
# names(dist.copy) <- data[,'FileName']
# for (i in 1:length(dist.copy)) {
#   dist.copy[i] <- dist(xx[rownames(xx)==names(dist.copy)[i],])
# }
# hist(dist.copy,breaks=40,
#      main="Distances between technical replicates\nof the same picture",
#      xlab="Euclidean distance")
# dist.copy[dist.copy>0.06]
# names(dist.copy[dist.copy>0.08])
# rm(dist.copy)
#
#
## Look for large distances between individuals within species
# 
# species <- unique(data[,'CodeSpecies'])
# xx<-two.d.array(copy)
# rownames(xx) <- rep(data[,'FileName'])
# spe.names <- data[,'CodeSpecies']
# mean.dist.spe <- numeric(length(species))
# max.dist.spe <- numeric(length(species))
# names(mean.dist.spe) <- names(max.dist.spe) <- species
# for (i in 1:length(species)) {
#   if(length(xx[spe.names==species[i],1])==1) {
#     mean.dist.spe[i] <- NA
#     max.dist.spe[i] <- NA
#   }
#   else {
#     mean.dist.spe[i] <- mean(dist(xx[spe.names==species[i],]))
#     max.dist.spe[i] <- max(dist(xx[spe.names==species[i],]))    
#   }
# }
# hist(mean.dist.spe)
# hist(max.dist.spe)
# max.dist.spe[max.dist.spe>0.25]
# mean.dist.spe[mean.dist.spe>0.25]
# 
## test specific species
# a.species="GES_viridiflora"
# dist(xx[spe.names==a.species,])
# 
## END (NOT RUN)

# Procrustes ANOVA to quantify variation among technical replicates ------

xx<-two.d.array(res.gpa$coords)
rownames(xx) <- rep(data[,'FileName'],each=2)
res <- procD.lm(xx~rownames(xx),iter=999)
(result <- data.frame(variables=c("individuals","residuals","total"),
                      Sum_of_Squares=res$SS,Percent_Variance=round(res$SS/max(res$SS)*100,digits=2)))
# Results:
# 0.55% of variation between copies within specimens after 
#      solving problematic specimens
rm(res,result)


# Combine the two copies per individual ------------

copy <- res.gpa$coords[,,1:(dim(res.gpa$coords)[3]/2)]
for(i in 1:dim(copy)[3]) copy[,,i] <- (res.gpa$coords[,,i*2-1]+res.gpa$coords[,,i*2])/2


# Procrustes ANOVA ------------------------------------------

xx<-two.d.array(copy)

#
# Estimate sums of squares for mixed-pollination, hummingbird, 
# and bat syndromes

# hummingbird specialists
species.hum <- as.vector(data[data[,'Pollinator']=="hummingbird",'CodeSpecies'])
names(species.hum) <- data[data[,'Pollinator']=="hummingbird",'FileName']
xx.hum<-xx[data[,'Pollinator']=="hummingbird",]
rownames(xx.hum) <- data[data[,'Pollinator']=="hummingbird",'FileName']
(hum.res <- procD.lm(xx.hum~species.hum,iter=999))
data.frame(variables=c("species","residuals","total"),
                      Sum_of_Squares=res$SS,Percent_Variance=round(hum.res$SS/max(hum.res$SS)*100,digits=2))
# 80.54 % among species

# Morphological integration
hum.pca<-prcomp(xx.hum,center=T,scale=F)
var((hum.pca$sdev^2)/sum(hum.pca$sdev^2))
# 0.07055069

#
# Mixed-pollination species
species.gen <- as.vector(data[data[,'Pollinator']=="mixed-pollination",'CodeSpecies'])
names(species.gen) <- data[data[,'Pollinator']=="mixed-pollination",'FileName']
xx.gen<-xx[data[,'Pollinator']=="mixed-pollination",]
rownames(xx.gen) <- data[data[,'Pollinator']=="mixed-pollination",'FileName']
(gen.res <- procD.lm(xx.gen~species.gen,iter=999))
data.frame(variables=c("species","residuals","total"),
           Sum_of_Squares=res$SS,Percent_Variance=round(gen.res$SS/max(gen.res$SS)*100,digits=2))
# 58.29 % among species

# Morphological integration
gen.pca<-prcomp(xx.gen,center=T,scale=F)
var((gen.pca$sdev^2)/sum(gen.pca$sdev^2))
# 0.08304858

#
# bat specialists
species.bat <- as.vector(data[data[,'Pollinator']=="bat",'CodeSpecies'])
names(species.bat) <- data[data[,'Pollinator']=="bat",'FileName']
xx.bat<-xx[data[,'Pollinator']=="bat",]
rownames(xx.bat) <- data[data[,'Pollinator']=="bat",'FileName']
(bat.res <- procD.lm(xx.bat~species.bat,iter=999))
data.frame(variables=c("species","residuals","total"),
           Sum_of_Squares=bat.res$SS,Percent_Variance=round(bat.res$SS/max(bat.res$SS)*100,digits=2))
# 91.2 % among species

# Morphological integration
bat.pca<-prcomp(xx.bat,center=T,scale=F)
var((bat.pca$sdev^2)/sum(bat.pca$sdev^2))
# 0.1946622

rm(xx,species.bat,xx.bat,species.gen,xx.gen,species.hum,xx.hum,
   hum.res,gen.res,bat.res)


# Principal Component Analysis ---------------------------------------------

# PCA on individual coordinates
copy.mat<-two.d.array(copy)
res.pca<-prcomp(copy.mat,center=T,scale=F)
summary(res.pca)

# Thin-plate spline transformation grids

c = 2 # scale for plotting (multiple of standard deviation)
meanshape <- matrix(res.pca$center,ncol=2,byrow=TRUE)
pc1min <- matrix(res.pca$center-(c*res.pca$sdev[1])*res.pca$rotation[,1],ncol=2,byrow=T)
pc1max <- matrix(res.pca$center+(c*res.pca$sdev[1])*res.pca$rotation[,1],ncol=2,byrow=T)
pc2min <- matrix(res.pca$center-(c*res.pca$sdev[2])*res.pca$rotation[,2],ncol=2,byrow=T)
pc2max <- matrix(res.pca$center+(c*res.pca$sdev[2])*res.pca$rotation[,2],ncol=2,byrow=T)
op <- par(mfrow=c(2,2),mar=c(0,0,0,0))
tps1(meanshape, pc1min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc1max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc2min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc2max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
par(op)


# Calculate mean PC coordinates per species
species <- unique(data[,'CodeSpecies'])
res.tan.spe<-matrix(data=NA,nrow=length(species),ncol=2)
for (i in 1:length(species)){
  if(length(data[data[,'CodeSpecies']==species[i],1])==1) {
    res.tan.spe[i,]<-res.pca$x[data[,'CodeSpecies']==species[i],1:2]
  }
  else 
    res.tan.spe[i,]<-apply(res.pca$x[data[,'CodeSpecies']==species[i],1:2],2,mean)
}
rownames(res.tan.spe) <- species

rm(copy.mat,c,meanshape,pc1min,pc1max,pc2min,pc2max)


# PCA figures for the paper ---------------------------------------------------

# Create table to draw lines
tab.lines<-matrix(nrow=nrow(res.pca$x),ncol=2)
for(i in 1:nrow(res.pca$x)) {
  tab.lines[i,]<-res.tan.spe[species==data[i,"CodeSpecies"]]
}

# Get pollinator information
pol<-as.vector(data[!duplicated(data[,'CodeSpecies']),'Pollinator'])
pol[data[!duplicated(data[,'CodeSpecies']),'Confirmed']=="no"] <- "unknown"
pol <- as.factor(pol)
spe.names<-data[!duplicated(data[,'CodeSpecies']),'CodeSpecies']

# With ggplot2
require(ggplot2)

# Data for lines - ggplot
all.pol <- as.vector(data[,'Pollinator'])
all.pol[data[,'Confirmed']=="no"] <- "unknown"
all.pol <- as.factor(all.pol)
amatrix <- data.frame(PC1=numeric(),PC2=numeric(),pollinator=factor(character(),levels=c("bat","hummingbird","mixed-pollination","unknown")),species=numeric())
for (i in 1:nrow(res.pca$x)) {
  amatrix <- rbind(amatrix,
                   data.frame(PC1=tab.lines[i,1],PC2=tab.lines[i,2],pollinator=all.pol[i],species=i),
                   data.frame(PC1=res.pca$x[i,1],PC2=res.pca$x[i,2],pollinator=all.pol[i],species=i))
}
tab.lines.ggplot <- amatrix


# data.frames
data1 <- data.frame(species=spe.names,PC1=res.tan.spe[,1],
                            PC2=res.tan.spe[,2],pollinator=pol,
                            type="species", size=2)
data2 <- data.frame(species=data[,'FileName'],
                            PC1=res.pca$x[,1],PC2=res.pca$x[,2],
                            pollinator=all.pol,
                            type="individual", size=0.5)

pdf("PCA_ggplot.pdf",height=5,width=8)
op <- par(mar=c(3.5,3.5,1,1),mgp=c(1.5,0.5,0),tcl=0.3)
p <- ggplot(tab.lines.ggplot, aes(x=PC1,y=PC2,colour=pollinator,group=species)) + 
  geom_path(size=0.5,alpha=0.8) + 
  geom_point(data=data2, aes(x=PC1,y=PC2,colour=pollinator), size=2, alpha=0.9) + 
  geom_point(data=data1, aes(x=PC1,y=PC2,colour=pollinator), size=6, alpha=0.75) + 
  theme_minimal() + labs(colour = "Pollination syndrome") + 
  lims(x = c(-0.45, 0.5), y = c(-0.65, 0.4)) +
  theme(legend.justification=c(1,0), legend.position=c(1,0), legend.background = element_rect(fill="gray95",colour=NA)) + 
  scale_colour_manual(values = c("#1b9e77","#d95f02","#7570b3","#e78ac3","gray"))
p
par(op)
dev.off()

# Supplementary figure
require(plotly)
new.tab.lines <- tab.lines.ggplot[0,]
for (i in 1:(nrow(tab.lines.ggplot)/2)) {
  new.tab.lines <- rbind(new.tab.lines,tab.lines.ggplot[c(i*2-1,i*2),],NA)
}
data1$pollinator <- factor(as.vector(data1$pollinator))
data2$pollinator <- factor(as.vector(data2$pollinator))
p <- plot_ly(new.tab.lines, type = "scatter", mode = "lines",
             x = PC1,  y = PC2, showlegend=FALSE, hoverinfo = "none",
             line = list(color="gray",width=1))
p <- add_trace(data2, type = "scatter", mode = "markers",
               x = PC1,  y = PC2,  
               color = pollinator, hoverinfo= "text",
               text = species, showlegend=FALSE,
               colors = c("#1b9e77","#d95f02","#7570b3","#e78ac3","gray"),
               marker = list(opacity=0.8,size=8))
p <- add_trace(data1, type = "scatter", mode = "markers",
               x = PC1,  y = PC2, 
               color = pollinator, hoverinfo= "text",
               text = species, showlegend=TRUE,
               colors = c("#1b9e77","#d95f02","#7570b3","#e78ac3","gray"),
               marker = list(opacity=0.8,size=18))
p <- layout(p, hovermode="closest")      
p


# PCA on mixed-pollination and bat specialists ----------------------------------

# This analysis is mentionned as "data not shown" in the paper

copy.mat<-two.d.array(copy)
genbat.pca<-prcomp(copy.mat[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),],
                   center=T,scale=F)
summary(genbat.pca)

# Thin-plate spline transformation grids

c = 2 # scale for plotting (multiple of standard deviation)
meanshape <- matrix(genbat.pca$center,ncol=2,byrow=TRUE)
pc1min <- matrix(genbat.pca$center-(c*genbat.pca$sdev[1])*genbat.pca$rotation[,1],ncol=2,byrow=T)
pc1max <- matrix(genbat.pca$center+(c*genbat.pca$sdev[1])*genbat.pca$rotation[,1],ncol=2,byrow=T)
pc2min <- matrix(genbat.pca$center-(c*genbat.pca$sdev[2])*genbat.pca$rotation[,2],ncol=2,byrow=T)
pc2max <- matrix(genbat.pca$center+(c*genbat.pca$sdev[2])*genbat.pca$rotation[,2],ncol=2,byrow=T)
pc3min <- matrix(genbat.pca$center-(c*genbat.pca$sdev[3])*genbat.pca$rotation[,3],ncol=2,byrow=T)
pc3max <- matrix(genbat.pca$center+(c*genbat.pca$sdev[3])*genbat.pca$rotation[,3],ncol=2,byrow=T)
op <- par(mfrow=c(3,2),mar=c(0,0,0,0))
tps1(meanshape, pc1min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc1max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc2min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc2max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc3min, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
tps1(meanshape, pc3max, n=20,sz=1.2, pt.bg="grey15",
     grid.col="grey60", grid.lwd=1, grid.lty=1, refpts=FALSE)
par(op)

# Plot PCA

# Calculate mean PC coordinates per species
genbat.species <- unique(data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'CodeSpecies'])
mean.genbat.tan<-matrix(data=NA,nrow=length(genbat.species),ncol=3)
for (i in 1:length(genbat.species)){
  if(length(data[data[,'CodeSpecies']==genbat.species[i],1])==1) {
    mean.genbat.tan[i,]<-genbat.pca$x[data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'CodeSpecies']==genbat.species[i],c(1:3)]
  }
  else 
    mean.genbat.tan[i,]<-apply(genbat.pca$x[data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'CodeSpecies']==genbat.species[i],1:3],2,mean)
}
rownames(mean.genbat.tan) <- genbat.species

# Get pollinator info for species means
mean.genbat.pol <- as.vector(data[match(genbat.species,data$CodeSpecies),'Pollinator'])
mean.genbat.pol[data[match(genbat.species,data$CodeSpecies),'Confirmed']=="no"] <- "unknown"
mean.genbat.pol <- factor(mean.genbat.pol)
genbat.pol <- as.vector(data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'Pollinator'])
genbat.pol[data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'Confirmed']=="no"] <- "unknown"
genbat.pol <- factor(genbat.pol)

# Create table to draw lines
genbat.tab.lines<-matrix(nrow=nrow(genbat.pca$x),ncol=3)
for(i in 1:nrow(genbat.pca$x)) {
  genbat.tab.lines[i,]<-mean.genbat.tan[genbat.species==data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),"CodeSpecies"][i]]
}

# plot with ggplot2
require(ggplot2)
gen.bat.data1 <- data.frame(species=genbat.species,PC2=mean.genbat.tan[,2],
                            PC3=mean.genbat.tan[,3],pollinator=mean.genbat.pol,
                            type="species", size=2)
gen.bat.data2 <- data.frame(species=data[(data[,'Pollinator']!="hummingbird" & data[,'CodeSpecies']!="GES_humilis"),'FileName'],
                            PC2=genbat.pca$x[,2],PC3=genbat.pca$x[,3],
                            pollinator=genbat.pol,
                            type="individual", size=0.5)
# Data for lines - ggplot
amatrix <- data.frame(PC2=numeric(),PC3=numeric(),pollinator=factor(character(),levels=c("bat","mixed-pollination","unknown")),species=numeric())
for (i in 1:nrow(genbat.pca$x)) {
  amatrix <- rbind(amatrix,
                   data.frame(PC2=genbat.tab.lines[i,2],PC3=genbat.tab.lines[i,3],pollinator=genbat.pol[i],species=i),
                   data.frame(PC2=genbat.pca$x[i,2],PC3=genbat.pca$x[i,3],pollinator=genbat.pol[i],species=i))
}
gen.bat.data.lines.ggplot <- amatrix

pdf("PCA_no_hummingbirds_ggplot.pdf",height=5,width=8)
op <- par(mar=c(3.5,3.5,1,1),mgp=c(1.5,0.5,0),tcl=0.3)
p <- ggplot(gen.bat.data.lines.ggplot, aes(x=PC2,y=PC3,colour=as.factor(pollinator),group=species)) + 
  geom_path(size=0.5,alpha=0.8) + 
  geom_point(data=gen.bat.data2, aes(x=PC2,y=PC3,colour=pollinator), size=2,alpha=0.9) + 
  geom_point(data=gen.bat.data1, aes(x=PC2,y=PC3,colour=pollinator), size=6,alpha=0.75) + 
  theme_minimal() + labs(colour = "Pollination syndrome") + 
  lims(x = c(-0.25, 0.35), y = c(-0.22, 0.3)) +
  theme(legend.justification=c(1,0), legend.position=c(1,0), legend.background = element_rect(fill="gray95",colour=NA)) + 
  scale_colour_manual(values = c("#1b9e77","#7570b3","gray"))
p
par(op)
dev.off()

# supplemetary figure -----
library(plotly)
amatrix <- matrix(NA,ncol=2,nrow=0)
for (i in 1:nrow(genbat.pca$x)) {
  amatrix <- rbind(amatrix,genbat.tab.lines[i,c(2,3)],genbat.pca$x[i,c(2,3)],c(NA,NA))  
}
gen.bat.data.lines <- data.frame(PC2=amatrix[,1],PC3=amatrix[,2])

p <- plot_ly(gen.bat.data.lines, type = "scatter", mode = "lines",
             x = PC2,  y = PC3, showlegend=FALSE, hoverinfo = "none",
             line = list(color="gray",width=1))
p <- add_trace(gen.bat.data2, type = "scatter", mode = "markers",
             x = PC2,  y = PC3,  
             color = pollinator, hoverinfo= "text",
             text = species, showlegend=FALSE,
             colors = c("#1b9e77","#7570b3","gray"),
             marker = list(opacity=0.8,size=8))
p <- add_trace(gen.bat.data1, type = "scatter", mode = "markers",
               x = PC2,  y = PC3, 
               color = pollinator, hoverinfo= "text",
               text = species, showlegend=TRUE,
               colors = c("#1b9e77","#7570b3","gray"),
               marker = list(opacity=0.8,size=18))
p <- layout(p, hovermode="closest")      
p

figS3 <- p

save(list=c("gen.bat.data.lines","gen.bat.data1","gen.bat.data2",
            "new.tab.lines","data1","data2","figS4"),
      file="data_supp_figs.RData")

save(list=c("figS2","figS3","figS4"),
     file="data_supp_figs.RData")

rm(copy.mat,genbat.pca,c,meanshape,pc1min,pc1max,pc2min,pc2max,pc3min,pc3max,genbat.pol)


# Ancestral state reconstruction (MCC tree) - model selection ----------

#Read syndrome data
syndata <- read.csv("species.csv", sep=";", header=TRUE)
syndata <- syndata[,c(1,4:5)]
rownames(syndata) <- syndata[,'CodeSpecies']

#Open tree
spe.tree <- read.nexus("BestTree.tre")

#Change species names to fit that of the table
spe.tree$tip.label <- sub("G","GES_",spe.tree$tip.label)
spe.tree$tip.label <- sub("R","RHY_",spe.tree$tip.label)
spe.tree$tip.label <- sub("B","BEL_",spe.tree$tip.label)

#Remove species for which we don't have data
exclude.nodata <- unique(as.vector(syndata[!(as.vector(syndata[,"CodeSpecies"]) %in% spe.tree$tip.label),"CodeSpecies"]))
exclude.nodata2 <- spe.tree$tip.label[!(spe.tree$tip.label %in% as.vector(syndata[,"CodeSpecies"]))]
exclude <- unique(c(exclude.nodata,exclude.nodata2))
spe.tree <- drop.tip(spe.tree,exclude)

# Remove species for which pollination modes are unknown
exclude.nodata3 <- spe.tree$tip.label[!(spe.tree$tip.label %in% syndata[syndata[,"Pollinator"]!="unknown","CodeSpecies"])]
spe.tree <- drop.tip(spe.tree,exclude.nodata3)

#Reorder data frame
syndata <- syndata[match(spe.tree$tip.label,rownames(syndata)),]

#Vector of pollinator data
pollinator.data <- as.factor(as.vector(syndata$Pollinator))
names(pollinator.data) <- syndata[,'CodeSpecies']

#Test different evolutionary models
library(geiger)
results.anc <- data.frame(model=c("ER","ER.2","SYM","SYM.2","ARD","ARD.2","from.to","hum.2.other"),
                          lnL=numeric(8),AICc=numeric(8),params=numeric(8))
char1 <- as.vector(pollinator.data)
names(char1) <- spe.tree$tip.label
# ER
(pol_anc <- fitDiscrete(spe.tree,char1,model="ER"))
results.anc[1,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# ER.2
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 2, 2, 1,  1, 0, 1, 1, 1, 
                                       2, 1, 0, 2, 1, 
                                       2, 1, 2, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[2,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# SYM
(pol_anc <- fitDiscrete(spe.tree,char1,model="SYM"))
results.anc[3,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# SYM.2
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 2, 3, 1,  1, 0, 1, 1, 1, 
                                       2, 1, 0, 4, 1, 
                                       3, 1, 4, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[4,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# ARD
(pol_anc <- fitDiscrete(spe.tree,char1,model="ARD"))
results.anc[5,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# ARD.2
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 2, 3, 1,  1, 0, 1, 1, 1, 
                                       4, 1, 0, 5, 1, 
                                       6, 1, 7, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[6,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# from.to
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 3, 4, 1,  1, 0, 1, 1, 1, 
                                       2, 1, 0, 4, 1, 
                                       2, 1, 3, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[7,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# hum.2.other
(pol_anc <- fitDiscrete(spe.tree,char1,
                        model=matrix(c(0, 1, 2, 3, 1,  1, 0, 1, 1, 1, 
                                       3, 1, 0, 3, 1, 
                                       3, 1, 2, 0, 1,  1, 1, 1, 1, 0), 5)) )
results.anc[8,-1]<- c(lnL=pol_anc$opt$lnL,AICc=pol_anc$opt$aicc,pol_anc$opt$k)
# Order results by AICc
results.anc[order(results.anc$AICc),]
# Best model: hum.2.others


#Stochastic mapping
require(phytools)
set.seed(1234)
#Stochastic character mapping
chartrees <- make.simmap(spe.tree, pollinator.data,
                         model=matrix(c(0, 1, 2, 3, 1, 1, 0, 1, 1, 1, 3, 1, 0, 3, 1, 3, 1, 2, 0, 1, 1, 1, 1, 1, 0), 5),
                         nsim = 2000)

## plot one instance (NOT RUN)
# cols <- setNames(c("#1b9e77","#7570b3","#d95f02"), sort(unique(pollinator.data)))
# plotSimmap(chartrees[[2]], cols, pts = FALSE, lwd = 3, fsize=0.6)
# legend("bottomleft",legend=levels(pollinator.data),
#        lty=1,lwd=3,col=cols,bty="n",
#        text.col="gray32",cex=0.8,pt.cex=1.5)

# Output summary information
(res_simmap <- describe.simmap(chartrees, plot = FALSE))

# Plot the tree with posterior probabilities of states at each node
cols <- setNames(c("#1b9e77","goldenrod","#d95f02","#7570b3","#e78ac3"), sort(unique(pollinator.data)))
plot(spe.tree,type="p",FALSE,label.offset=0.6,cex=0.7,no.margin=TRUE,
     edge.color="gray32",tip.color="gray32")
tiplabels(pch=21,bg=cols[as.numeric(pollinator.data)],col="gray32",cex=1,adj=0.6)
nodelabels(pie=res_simmap$ace,piecol=cols,cex=0.5,col="gray32")
legend("bottomleft",legend=levels(pollinator.data),
       pch=20,col=cols,bty="n",
       text.col="gray32",cex=0.8,pt.cex=1.5)



# Get mean shapes per species for phylogeny ----

require(ape)
spe.tree <- read.nexus("BestTree.tre")

#Change species names to fit that of the table
spe.tree$tip.label <- sub("G","GES_",spe.tree$tip.label)
spe.tree$tip.label <- sub("R","RHY_",spe.tree$tip.label)

#Remove species for which we don't have data
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% spe.tree$tip.label),"CodeSpecies"]))
exclude.nodata2 <- spe.tree$tip.label[!(spe.tree$tip.label %in% as.vector(data[,"CodeSpecies"]))]
exclude <- unique(c(exclude.nodata,exclude.nodata2))
spe.tree <- drop.tip(spe.tree,exclude)

# Order data according to tree tips
# Calculate mean PC coordinates per species
species <- unique(data[,'CodeSpecies'])
res.tan.spe<-matrix(data=NA,nrow=length(species),ncol=64)
for (i in 1:length(species)){
  if(length(data[data[,'CodeSpecies']==species[i],1])==1) {
    res.tan.spe[i,]<-res.pca$x[data[,'CodeSpecies']==species[i],]
  }
  else 
    res.tan.spe[i,]<-apply(res.pca$x[data[,'CodeSpecies']==species[i],],2,mean)
}
rownames(res.tan.spe) <- species
res.tan.spe <- res.tan.spe[match(spe.tree$tip.label,rownames(res.tan.spe)),]

# Vector of pollinator data
pollinator.data <- data[match(rownames(res.tan.spe),data[,'CodeSpecies']),'Pollinator']
pollinator.data <- as.factor(as.vector(pollinator.data))

# Get mean corolla shapes per species
species.shapes <- matrix(nrow=nrow(res.tan.spe),ncol=64)
rownames(species.shapes) <- rownames(res.tan.spe)
for (i in 1:nrow(res.tan.spe)){
  species.shapes[i,] <- res.pca$center + 
    apply(sweep(res.pca$rotation[,],MARGIN=2,res.tan.spe[i,],'*'),MARGIN=1,sum)
}

# Plot mean corolla chapes per species
pdf("shapes_nonames.pdf",height=30,width=3)
par(mar=c(0,0,0,0),mfrow=c(nrow(species.shapes),1),mgp=c(-0.5,0,0))
for (i in 1:nrow(species.shapes)) {
  plot(matrix(species.shapes[i,],ncol=2,byrow=T),axes=F,
       xlab="",
       ylab="",pch=21,bg="black",cex=0.7,
       xlim=c(-0.4,0.4),ylim=c(-0.4,0.4),asp=1)
}
par(op)
dev.off()

pdf("shapes_withnames.pdf",height=30,width=3)
par(mar=c(0,0,0,0),mfrow=c(nrow(species.shapes),1),mgp=c(-0.5,0,0))
for (i in 1:nrow(species.shapes)) {
  plot(matrix(species.shapes[i,],ncol=2,byrow=T),axes=F,
       xlab=rownames(species.shapes)[i],
       ylab="",pch=21,bg="black",cex=0.6,
       xlim=c(-0.4,0.4),ylim=c(-0.4,0.4),asp=1)
}
par(op)
dev.off()


# Ancestral state reconstruction (MCC tree) ----------

#Read syndrome data
syndata <- read.csv("species.csv", sep=";", header=TRUE)
syndata <- syndata[,c(1,4:5)]
rownames(syndata) <- syndata[,'CodeSpecies']

#Open tree
spe.tree <- read.nexus("BestTree.tre")

#Change species names to fit that of the table
spe.tree$tip.label <- sub("G","GES_",spe.tree$tip.label)
spe.tree$tip.label <- sub("R","RHY_",spe.tree$tip.label)
spe.tree$tip.label <- sub("B","BEL_",spe.tree$tip.label)

#Remove species for which we don't have data
exclude.nodata <- unique(as.vector(syndata[!(as.vector(syndata[,"CodeSpecies"]) %in% spe.tree$tip.label),"CodeSpecies"]))
exclude.nodata2 <- spe.tree$tip.label[!(spe.tree$tip.label %in% as.vector(syndata[,"CodeSpecies"]))]
exclude <- unique(c(exclude.nodata,exclude.nodata2))
spe.tree <- drop.tip(spe.tree,exclude)

# Remove species for which pollination modes are not confirmed
#exclude.nodata3 <- spe.tree$tip.label[!(spe.tree$tip.label %in% syndata[syndata[,"Confirmed"]!="no","CodeSpecies"])]
#spe.tree <- drop.tip(spe.tree,exclude.nodata3)

#Reorder data frame
syndata <- syndata[match(spe.tree$tip.label,rownames(syndata)),]

#Vector of pollinator data
pollinator.data <- as.factor(as.vector(syndata$Pollinator))
names(pollinator.data) <- syndata[,'CodeSpecies']

chartrees <- make.simmap(spe.tree, pollinator.data,
                         model=matrix(c(0, 1, 2, 3, 1, 1, 0, 1, 1, 1, 3, 1, 0, 3, 1, 3, 1, 2, 0, 1, 1, 1, 1, 1, 0), 5),
                         nsim = 2000)

# Output summary information
(res_simmap <- describe.simmap(chartrees, plot = FALSE))

# Plot the tree with posterior probabilities of states at each node
cols <- setNames(c("#1b9e77","goldenrod","#d95f02","#7570b3","#e78ac3"), sort(unique(pollinator.data)))
plot(spe.tree,type="p",FALSE,label.offset=0.6,cex=0.7,no.margin=TRUE,
     edge.color="gray32",tip.color="gray32")
tiplabels(pch=21,bg=cols[as.numeric(pollinator.data)],col="gray32",cex=1,adj=0.6)
nodelabels(pie=res_simmap$ace,piecol=cols,cex=0.5,col="gray32")
legend("bottomleft",legend=levels(pollinator.data),
       pch=20,col=cols,bty="n",
       text.col="gray32",cex=0.8,pt.cex=1.5)

###
# Analysis with only confirmed syndromes:

# Assign equal prior prob. for the different syndromes 
# for undetermined species
pollinator.prior <- model.matrix(~pollinator.data)
rownames(pollinator.prior) <- names(pollinator.data)
colnames(pollinator.prior) <- levels(pollinator.data)
pollinator.prior[,1] <- 0
for (row in 1:nrow(pollinator.prior)) if (sum(pollinator.prior[row,])==0) pollinator.prior[row,1]<-1
undetermined <- spe.tree$tip.label[!(spe.tree$tip.label %in% syndata[syndata[,"Confirmed"]!="no","CodeSpecies"])]
for (row in 1:nrow(pollinator.prior))
  if (rownames(pollinator.prior)[row] %in% undetermined)
    pollinator.prior[row,] <- rep(0.2,length.out=5)

chartrees <- make.simmap(spe.tree, pollinator.prior,
                         model=matrix(c(0, 1, 2, 3, 1, 1, 0, 1, 1, 1, 3, 1, 0, 3, 1, 3, 1, 2, 0, 1, 1, 1, 1, 1, 0), 5),
                         nsim = 2000)

# Output summary information
(res_simmap <- describe.simmap(chartrees, plot = FALSE))

# Plot the tree with posterior probabilities of states at each node
cols <- setNames(c("#1b9e77","goldenrod","#d95f02","#7570b3","#e78ac3"), sort(unique(pollinator.data)))
plot(spe.tree,type="p",FALSE,label.offset=2,cex=0.7,no.margin=TRUE,edge.color="gray32",tip.color="gray32")
tiplabels(pie=pollinator.prior,piecol=cols,col="gray32",cex=0.5,adj=1.5)
nodelabels(pie=res_simmap$ace,piecol=cols,cex=0.5,col="gray32")
legend("bottomleft",legend=levels(pollinator.data),
       pch=20,col=cols,bty="n",
       text.col="gray32",cex=0.8,pt.cex=1.5)


# ASR posterior distribution of species trees ------------

#Read syndrome data
syndata <- read.csv("species.csv", sep=";", header=TRUE)
syndata <- syndata[,c(1,4:5)]
rownames(syndata) <- syndata[,'CodeSpecies']

# Read a random sample from the tree posterior
require(ape)
#spe.trees <- read.nexus("AllTrees.trees")
#set.seed(3246)
#random.trees<-sample(spe.trees,size=5000)
#rm(spe.trees)
random.trees <- read.nexus("FiveThousandTrees.trees")

# Change species names to fit that of the table
attr(random.trees,"TipLabel") <- sub("G","GES_",random.trees$tip.label$tip.label)
attr(random.trees,"TipLabel") <- sub("R","RHY_",random.trees$tip.label$tip.label)
attr(random.trees,"TipLabel") <- sub("B","BEL_",random.trees$tip.label$tip.label)

#Remove species for which we don't have data or pollination modes are unknown
exclude.nodata <- unique(as.vector(syndata[!(as.vector(syndata[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% as.vector(syndata[,"CodeSpecies"]))]
exclude <- unique(c(exclude.nodata,exclude.nodata2))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

#Reorder data frame
syndata <- syndata[match(attr(random.trees,"TipLabel"),rownames(syndata)),]

#Vector of pollinator data
pollinator.data <- as.factor(as.vector(syndata$Pollinator))
names(pollinator.data) <- syndata[,'CodeSpecies']

# Stochastic mapping on posterior to get credible intervals

## For simulations of cluster (NOT RUN)
# save(random.trees,pollinator.data,file="stochastic_mapping.Rdata")
# load(file="stochastic_mapping.Rdata")

one.asr.sim <- function(trees,tree.nb,regimes) {
  #cat("Processing replicate",tree.nb,"\n")  
  mytree<-trees[[tree.nb]]
  # simulate single stochastic character map using empirical Bayes method
  require(phytools)
  chartrees <- make.simmap(mytree, regimes, model=matrix(c(0, 3, 1, 2, 3, 0, 3, 3, 2, 3, 0, 2, 2, 3, 1, 0), 4), 
                           Q=matrix(c(-216.1, 8.7,  34.4,   99.4,  8.7,
                                      8.7,  -34.6,    8.7,    8.7, 8.7,
                                      99.4,   8.7, -86,     99.4, 8.7,
                                      99.4,  8.7,   34.3, -216.1,  8.7,
                                      8.7,    8.7,    8.7,    8.7, -34.4), 5, dimnames=list(c("bat","bee","hummingbird","mixed-pollination","moth"),c("bat","bee","hummingbird","mixed-pollination","moth"))),
                           nsim = 500, message=F)
  res_simmap <- describe.simmap(chartrees, plot = FALSE)
  if (ncol(res_simmap$count)!=21) break #Check for errors!
  #change.matrix.table[tree.nb,] <- apply(res_simmap$count,2,mean)
  apply(res_simmap$count,2,mean)
}

# The simulations
library(parallel)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir/asr_out.txt") # Initiate cluster
replicates=50
set.seed(1234)
res.asr <- parSapply(cl,seq(1,length.out=replicates),function(c) one.asr.sim(trees=random.trees,tree.nb=c,regimes=pollinator.data))
stopCluster(cl)

apply(res.asr,1, function(c) round(quantile(c,probs=c(0.025,0.5,0.975)),2))

#For cluster analysis (NOT RUN)
#save(change.matrix.table,file="change.matrix.table")


# ASR posterior distribution of trees - confirmed syndomes ------------

# Assign equal prior prob. for the different syndromes 
# for undetermined species
pollinator.prior <- model.matrix(~pollinator.data)
rownames(pollinator.prior) <- names(pollinator.data)
colnames(pollinator.prior) <- levels(pollinator.data)
pollinator.prior[,1] <- 0
for (row in 1:nrow(pollinator.prior)) if (sum(pollinator.prior[row,])==0) pollinator.prior[row,1]<-1
undetermined <- spe.tree$tip.label[!(spe.tree$tip.label %in% syndata[syndata[,"Confirmed"]!="no","CodeSpecies"])]
for (row in 1:nrow(pollinator.prior))
  if (rownames(pollinator.prior)[row] %in% undetermined)
    pollinator.prior[row,] <- rep(0.2,length.out=5)

## For simulations of cluster (NOT RUN)
# save(random.trees,pollinator.prior,file="stochastic_mapping.Rdata")
# load(file="stochastic_mapping.Rdata")

# The simulations
library(parallel)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir/asr_out.txt") # Initiate cluster
replicates=50
set.seed(1234)
res.asr <- parSapply(cl,seq(1,length.out=replicates),function(c) one.asr.sim(trees=random.trees,tree.nb=c,regimes=pollinator.prior))
stopCluster(cl)

apply(res.asr,1, function(c) round(quantile(c,probs=c(0.025,0.5,0.975)),2))


# Beta-disper on species means -------

# remove species with unkown syndromes
spe.data <- res.tan.spe[pollinator.data != "unknown",]
pol.data <- factor(as.vector(pollinator.data[pollinator.data != "unknown"]))
require(vegan)
beta.dist <- betadisper(dist(spe.data),pol.data)
beta.dist
anova(beta.dist)
plot(beta.dist)
boxplot(beta.dist,ylab="Distance to centroid")
TukeyHSD(beta.dist,which="group",conf.level=0.95)



# mvMORPH, censored model ------

random.trees <- read.nexus("FiveThousandTrees.trees")

# Change species names to fit that of the table
attr(random.trees,"TipLabel") <- sub("G","GES_",random.trees$tip.label$tip.label)
attr(random.trees,"TipLabel") <- sub("R","RHY_",random.trees$tip.label$tip.label)

# To filter the taxa, use one of the following blocks

# 1: Remove species for which we don't have data
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

# 2: Use only confirmed species
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
exclude.nodata4 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Confirmed"]=="no","CodeSpecies"])]
exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3,exclude.nodata4))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

# 3: Use inferred syndromes for hummingbird inferred, else confirmed (not shown in the paper)
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
exclude.nodata4 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[((data[,"Confirmed"]=="no") & (data[,"Pollinator"] == "mixed-pollination")),"CodeSpecies"])]
exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3,exclude.nodata4))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label


# Order data according to tree tips
# Calculate mean PC coordinates per species
species <- unique(data[,'CodeSpecies'])
res.tan.spe<-matrix(data=NA,nrow=length(species),ncol=64)
for (i in 1:length(species)){
  if(length(data[data[,'CodeSpecies']==species[i],1])==1) {
    res.tan.spe[i,]<-res.pca$x[data[,'CodeSpecies']==species[i],]
  }
  else 
    res.tan.spe[i,]<-apply(res.pca$x[data[,'CodeSpecies']==species[i],],2,mean)
}
rownames(res.tan.spe) <- species
res.tan.spe <- res.tan.spe[match(attr(random.trees,"TipLabel"),rownames(res.tan.spe)),]
colnames(res.tan.spe) = sapply(1:ncol(res.tan.spe),function(c) paste("PC",c,sep=""))

# Vector of pollinator data
pollinator.data <- data[match(rownames(res.tan.spe),data[,'CodeSpecies']),'Pollinator']
pollinator.data <- as.factor(as.vector(pollinator.data))
names(pollinator.data) <- data[match(rownames(res.tan.spe),data[,'CodeSpecies']),'CodeSpecies']


###
# Calculate intraspecific standard error to include 
# as error term in model fitting

data.spe.gen <- res.tan.spe[pollinator.data == "mixed-pollination",1:3]
data.ind.gen <- res.pca$x[data$Pollinator == "mixed-pollination",1:3]
rownames(data.ind.gen) <- data$CodeSpecies[data$Pollinator == "mixed-pollination"]
sd.error.gen <- matrix(nrow=nrow(data.spe.gen),ncol=3)
rownames(sd.error.gen) <- rownames(data.spe.gen)
colnames(sd.error.gen) <- colnames(data.spe.gen)
for (i in 1:nrow(sd.error.gen)) {
  temp <- data.ind.gen[rownames(data.ind.gen) == rownames(data.spe.gen)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.gen[i,1] <- sd.error.gen[i,2] <- sd.error.gen[i,3] <- NA
    next
  }
  sd.error.gen[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.gen[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                          
  sd.error.gen[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                          
}
gen.error <- mean(sd.error.gen, na.rm=TRUE)
# Replace NAs by mean
sd.error.gen[is.na(sd.error.gen)] <- gen.error

# Hummingbird specialists
data.spe.hum <- res.tan.spe[pollinator.data == "hummingbird",1:3]
data.ind.hum <- res.pca$x[data$Pollinator == "hummingbird",1:3]
rownames(data.ind.hum) <- data$CodeSpecies[data$Pollinator == "hummingbird"]
sd.error.hum <- matrix(nrow=nrow(data.spe.hum),ncol=3)
rownames(sd.error.hum) <- rownames(data.spe.hum)
colnames(sd.error.hum) <- colnames(data.spe.hum)
for (i in 1:nrow(sd.error.hum)) {
  temp <- data.ind.hum[rownames(data.ind.hum) == rownames(data.spe.hum)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.hum[i,1] <- sd.error.hum[i,2] <- sd.error.hum[i,3] <- NA
    next
  }
  sd.error.hum[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.hum[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                           
  sd.error.hum[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                           
}
hum.error <- mean(sd.error.hum, na.rm=TRUE)
# Replace NAs by mean
sd.error.hum[is.na(sd.error.hum)] <- hum.error

# Combine error matrices
sd.error <- rbind(sd.error.hum,sd.error.gen)
sd.error <- sd.error[attr(random.trees,"TipLabel"),]


# Make compound model
require(mvMORPH)
require(phytools)
source('utility_functions.R') # for the censoredtrees function

####
#
# Functions to obtain the models for each subtree (getMODELS)
#   and to get the compound model over all subtrees (mvCOMPOUND)
#

getMODELS <- function(trees,data,error,regimes,models=c("OU","OU")) {
  if(!is.matrix(data)) data <- data.frame(data)
  nb.trees = length(trees)
  themodels <- list()
  for(atree in 1:nb.trees) {
    if(models[regimes[atree]]=="OU") {
      thetree <- trees[[atree]]
      if(length(thetree$tip.label)<=2) next
      thedata <- data[match(thetree$tip.label,rownames(data)),]
      theerror <- error[match(thetree$tip.label,rownames(error)),]
      themodels <- c(themodels,list(mvOU(thetree,thedata,error=theerror,model="OU1",scale.height=FALSE,echo=FALSE,diagnostic=TRUE,optimization="fixed",
                                         param=list(decomp="diagonal",decompSigma="diagonal"))))
    }
    if(models[regimes[atree]]=="BM") {
      thetree <- trees[[atree]]
      if(length(thetree$tip.label)<=2) next
      thedata <- data[match(thetree$tip.label,rownames(data)),]
      theerror <- error[match(thetree$tip.label,rownames(error)),]
      themodels <- c(themodels,list(mvBM(thetree,thedata,error=theerror,model="BM1",scale.height=FALSE,echo=FALSE,diagnostic=TRUE,optimization="fixed",
                                         param=list(decomp="diagonal",decompSigma="diagonal"))))
    }
  }
  return(themodels)
}

getMODELScor <- function(trees,data,error,regimes,models=c("OU","OU")) {
  if(!is.matrix(data)) data <- data.frame(data)
  nb.trees = length(trees)
  themodels <- list()
  for(atree in 1:nb.trees) {
    if(models[regimes[atree]]=="OU") {
      thetree <- trees[[atree]]
      if(length(thetree$tip.label)<=2) next
      thedata <- data[match(thetree$tip.label,rownames(data)),]
      theerror <- error[match(thetree$tip.label,rownames(error)),]
      themodels <- c(themodels,list(mvOU(thetree,thedata,error=theerror,model="OU1",scale.height=FALSE,echo=FALSE,optimization="fixed")))
    }
    if(models[regimes[atree]]=="BM") {
      thetree <- trees[[atree]]
      if(length(thetree$tip.label)<=2) next
      thedata <- data[match(thetree$tip.label,rownames(data)),]
      theerror <- error[match(thetree$tip.label,rownames(error)),]
      themodels <- c(themodels,list(mvBM(thetree,thedata,error=theerror,model="BM1",scale.height=FALSE,echo=FALSE,optimization="fixed")))
    }
  }
  return(themodels)
}

#Compound likelihood function
mvCOMPOUND <- function(pars,themodels,regimes,model="OUOU",cor=FALSE) {
  nb.models <- length(themodels)
  llik <- numeric(nb.models)
  if(cor==FALSE) {
    for(atree in 1:nb.models) {
      if(model=="OUMVA"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:6],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[7:12],root.mle=FALSE)
      }
      if(model=="OUMA"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:6],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[c(7:8,3:4,9:10)],root.mle=FALSE)
      }
      if(model=="OUMV"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:6],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[c(1:2,7:10)],root.mle=FALSE)
      }
      if(model=="OUM"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:6],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[c(1:4,7:8)],root.mle=FALSE)
      }
      if(model=="OU1"){
        llik[atree] <- themodels[[atree]]$llik(pars[1:6],root.mle=FALSE)
      }
      if(model=="OUBM"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:6],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[7:10],root.mle=FALSE)
      }
      if(model=="BMOU"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:4],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[5:10],root.mle=FALSE)
      }
      if(model=="BMMV"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:4],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[5:8],root.mle=FALSE)
      }
      if(model=="BMM"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:4],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[c(1:2,5:6)],root.mle=FALSE)
      }
      if(model=="BM1"){
        llik[atree] <- themodels[[atree]]$llik(pars[1:4],root.mle=FALSE)
      }
    }    
  }
  if(cor==TRUE) {
    for(atree in 1:nb.models) {
      if(model=="OUMVA"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:8],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[9:16],root.mle=FALSE)
      }
      if(model=="OUMA"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:8],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[c(9:11,4:6,12:13)],root.mle=FALSE)
      }
      if(model=="OUMV"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:8],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[c(1:3,9:13)],root.mle=FALSE)
      }
      if(model=="OUM"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:8],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[c(1:6,9:10)],root.mle=FALSE)
      }
      if(model=="OU1"){
        llik[atree] <- themodels[[atree]]$llik(pars[1:8],root.mle=FALSE)
      }
      if(model=="OUBM"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:8],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[9:13],root.mle=FALSE)
      }
      if(model=="BMOU"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:5],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[6:13],root.mle=FALSE)
      }
      if(model=="BMMV"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:5],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[6:10],root.mle=FALSE)
      }
      if(model=="BMM"){
        if(regimes[atree]==1) llik[atree] <- themodels[[atree]]$llik(pars[1:5],root.mle=FALSE)
        if(regimes[atree]==2) llik[atree] <- themodels[[atree]]$llik(pars[c(1:3,6:7)],root.mle=FALSE)
      }
      if(model=="BM1"){
        llik[atree] <- themodels[[atree]]$llik(pars[1:5],root.mle=FALSE)
      }
    }    
  }
  return(sum(llik))
}


# mvCOMPOUND, posterior distribution ------------------------------------------------

# This function fits the data on all model for one tree of the posterior
# distribution

one.step.mvCOMPOUND <- function(trees,tree.nb,res.tan.spe,pollinator.data,
                              sd.error,vars=c(1:2)) {
  require(phytools)
  require(mvMORPH)
  source('utility_functions.R') # for the censoredtrees function
  
  cat("\nTree:",tree.nb,"\n")
  
  atree <- trees[[tree.nb]]
  
  # Rescale tree to unit length
  atree$edge.length <- atree$edge.length/max(nodeHeights(atree)[,2])

  #Stochastic mapping
  #set.seed(1234)
  chartrees <- make.simmap(atree, pollinator.data,model="ER",nsim=201)
  res_simmap <- describe.simmap(chartrees, plot = FALSE)
  
  if(any(res_simmap$ace[,1]==res_simmap$ace[,2])) {
    cat("\nSkipping tree",tree.nb,". Equal likelihood at nodes.\n\n")
    return(list(models=NULL,summary=NULL))
  }
  
  # Get ML state at each node
  anc_node<-factor(character(nrow(res_simmap$ace)),levels=levels(pollinator.data))
  for(i in 1:length(anc_node)) {
    anc_node[i] <- levels(pollinator.data)[res_simmap$ace[i,]==max(res_simmap$ace[i,])]
  }
  atree$node.label <- anc_node
  states <- c(as.vector(pollinator.data),as.vector(anc_node))
  
  #create mapping table (node number -> syndrome)
  mapping.table <- data.frame(node=seq(1,length(states)),syndrome=states)
  
  # Make censored trees
  res <- censoredtrees(tree=atree, map=mapping.table, combine.subtrees=FALSE)
  
  hum.trees <- res[[1]]
  mix.trees <- res[[2]]
  if(length(hum.trees)==0 | length(mix.trees)==0) next
  trees <- c(hum.trees, mix.trees)
  regimes <- rep(c(1,2),times=c(length(hum.trees),length(mix.trees)))
  
  ####
  # Fit models
  
  # OUMVA
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(5,1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes,models=c("OU","OU"))
  OUMVA.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMVA",cor=FALSE)},
                     method="BFGS", control=list(fnscale=-1, maxit=20000))
  OUMVA.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMVA.fit$par[1:2])$A 
  OUMVA.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMVA.fit$par[3:4])
  OUMVA.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMVA.fit$par[7:8])$A 
  OUMVA.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMVA.fit$par[9:10])
  OUMVA.fit$theta_hum=OUMVA.fit$par[5:6]
  OUMVA.fit$theta_mix=OUMVA.fit$par[11:12]
  hum.ou <- list(alpha=OUMVA.fit$alpha_hum,sigma=OUMVA.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMVA.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMVA.fit$alpha_mix,sigma=OUMVA.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMVA.fit$stationary_mix=stationary(mix.ou)
  OUMVA.fit$halflife_hum=halflife(hum.ou)
  OUMVA.fit$halflife_mix=halflife(mix.ou)
  OUMVA.fit$llik=OUMVA.fit$value
  OUMVA.fit$nparams=length(guess_values)
  OUMVA.fit$AIC=-2*OUMVA.fit$value+2*length(guess_values)
  OUMVA.fit$AICc=OUMVA.fit$AIC+((2*OUMVA.fit$nparams*(OUMVA.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMVA.fit$nparams-1))
  
  
  # OUMA (different theta, different alpha, shared sigma)
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(5,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUMA.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMA",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUMA.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMA.fit$par[1:2])$A 
  OUMA.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMA.fit$par[3:4])
  OUMA.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMA.fit$par[7:8])$A 
  OUMA.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMA.fit$par[3:4])
  OUMA.fit$theta_hum=OUMA.fit$par[5:6]
  OUMA.fit$theta_mix=OUMA.fit$par[9:10]
  hum.ou <- list(alpha=OUMA.fit$alpha_hum,sigma=OUMA.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMA.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMA.fit$alpha_mix,sigma=OUMA.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMA.fit$stationary_mix=stationary(mix.ou)
  OUMA.fit$halflife_hum=halflife(hum.ou)
  OUMA.fit$halflife_mix=halflife(mix.ou)
  OUMA.fit$llik=OUMA.fit$value
  OUMA.fit$nparams=length(guess_values)
  OUMA.fit$AIC=-2*OUMA.fit$value+2*length(guess_values)
  OUMA.fit$AICc=OUMA.fit$AIC+((2*OUMA.fit$nparams*(OUMA.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMA.fit$nparams-1))
  
  
  # OUMV (different theta, different sigma, shared alpha)
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUMV.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMV",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUMV.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMV.fit$par[1:2])$A 
  OUMV.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMV.fit$par[3:4])
  OUMV.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMV.fit$par[1:2])$A 
  OUMV.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMV.fit$par[7:8])
  OUMV.fit$theta_hum=OUMV.fit$par[5:6]
  OUMV.fit$theta_mix=OUMV.fit$par[9:10]
  hum.ou <- list(alpha=OUMV.fit$alpha_hum,sigma=OUMV.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMV.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMV.fit$alpha_mix,sigma=OUMV.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMV.fit$stationary_mix=stationary(mix.ou)
  OUMV.fit$halflife_hum=halflife(hum.ou)
  OUMV.fit$halflife_mix=halflife(mix.ou)
  OUMV.fit$llik=OUMV.fit$value
  OUMV.fit$nparams=length(guess_values)
  OUMV.fit$AIC=-2*OUMV.fit$value+2*length(guess_values)
  OUMV.fit$AICc=OUMV.fit$AIC+((2*OUMV.fit$nparams*(OUMV.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMV.fit$nparams-1))
  
  
  # OUM
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUM.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUM",cor=FALSE)},
                   method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUM.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUM.fit$par[1:2])$A 
  OUM.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUM.fit$par[3:4])
  OUM.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUM.fit$par[1:2])$A 
  OUM.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUM.fit$par[3:4])
  OUM.fit$theta_hum=OUM.fit$par[5:6]
  OUM.fit$theta_mix=OUM.fit$par[7:8]
  hum.ou <- list(alpha=OUM.fit$alpha_hum,sigma=OUM.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUM.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUM.fit$alpha_mix,sigma=OUM.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUM.fit$stationary_mix=stationary(mix.ou)
  OUM.fit$halflife_hum=halflife(hum.ou)
  OUM.fit$halflife_mix=halflife(mix.ou)
  OUM.fit$llik=OUM.fit$value
  OUM.fit$nparams=length(guess_values)
  OUM.fit$AIC=-2*OUM.fit$value+2*length(guess_values)
  OUM.fit$AICc=OUM.fit$AIC+((2*OUM.fit$nparams*(OUM.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUM.fit$nparams-1))
  
  
  # Model OU1
  guess_values <- rep(c(5,1,0),each=length(vars))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OU1.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OU1",cor=FALSE)},
                   method="BFGS", control=list(fnscale=-1, maxit=10000))
  OU1.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OU1.fit$par[1:2])$A 
  OU1.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OU1.fit$par[3:4])
  OU1.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OU1.fit$par[1:2])$A 
  OU1.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OU1.fit$par[3:4])
  OU1.fit$theta_hum=OU1.fit$par[5:6]
  OU1.fit$theta_mix=OU1.fit$par[5:6]
  hum.ou <- list(alpha=OU1.fit$alpha_hum,sigma=OU1.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OU1.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OU1.fit$alpha_mix,sigma=OU1.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OU1.fit$stationary_mix=stationary(mix.ou)
  OU1.fit$halflife_hum=halflife(hum.ou)
  OU1.fit$halflife_mix=halflife(mix.ou)
  OU1.fit$llik=OU1.fit$value
  OU1.fit$nparams=length(guess_values)
  OU1.fit$AIC=-2*OU1.fit$value+2*length(guess_values)
  OU1.fit$AICc=OU1.fit$AIC+((2*OU1.fit$nparams*(OU1.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OU1.fit$nparams-1))
  
  
  # Model OUBM
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","BM"))
  OUBM.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUBM",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=5000))
  OUBM.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUBM.fit$par[1:2])$A 
  OUBM.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUBM.fit$par[3:4])
  OUBM.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUBM.fit$par[7:8])
  OUBM.fit$theta_hum=OUBM.fit$par[5:6]
  OUBM.fit$theta_mix=OUBM.fit$par[9:10]
  hum.ou <- list(alpha=OUBM.fit$alpha_hum,sigma=OUBM.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUBM.fit$stationary_hum=stationary(hum.ou)
  OUBM.fit$halflife_hum=halflife(hum.ou)
  OUBM.fit$llik=OUBM.fit$value
  OUBM.fit$nparams=length(guess_values)
  OUBM.fit$AIC=-2*OUBM.fit$value+2*length(guess_values)
  OUBM.fit$AICc=OUBM.fit$AIC+((2*OUBM.fit$nparams*(OUBM.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUBM.fit$nparams-1))
  
  
  # Model BMOU
  guess_values <- c(rep(c(1,0),each=length(vars)),rep(c(5,1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","OU"))
  BMOU.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMOU",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMOU.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMOU.fit$par[1:2])
  BMOU.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(BMOU.fit$par[5:6])$A 
  BMOU.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMOU.fit$par[7:8])
  BMOU.fit$theta_hum=BMOU.fit$par[3:4]
  BMOU.fit$theta_mix=BMOU.fit$par[9:10]
  mix.ou <- list(alpha=BMOU.fit$alpha_mix,sigma=BMOU.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  BMOU.fit$stationary_mix=stationary(mix.ou)
  BMOU.fit$halflife_mix=halflife(mix.ou)
  BMOU.fit$llik=BMOU.fit$value
  BMOU.fit$nparams=length(guess_values)
  BMOU.fit$AIC=-2*BMOU.fit$value+2*length(guess_values)
  BMOU.fit$AICc=BMOU.fit$AIC+((2*BMOU.fit$nparams*(BMOU.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMOU.fit$nparams-1))
  
  
  # Model BMMV
  guess_values <- c(rep(c(1,0),each=length(vars)),rep(c(1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BMMV.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMMV",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMMV.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMMV.fit$par[1:2])
  BMMV.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMMV.fit$par[5:6])
  BMMV.fit$theta_hum=BMMV.fit$par[3:4]
  BMMV.fit$theta_mix=BMMV.fit$par[7:8]
  BMMV.fit$llik=BMMV.fit$value
  BMMV.fit$nparams=length(guess_values)
  BMMV.fit$AIC=-2*BMMV.fit$value+2*length(guess_values)
  BMMV.fit$AICc=BMMV.fit$AIC+((2*BMMV.fit$nparams*(BMMV.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMMV.fit$nparams-1))
  
  
  # Model BMM (different theta, shared sigma)
  guess_values <- c(rep(c(1,0),each=length(vars)),rep(c(0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BMM.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMM",cor=FALSE)},
                   method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMM.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMM.fit$par[1:2])
  BMM.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMM.fit$par[1:2])
  BMM.fit$theta_hum=BMM.fit$par[3:4]
  BMM.fit$theta_mix=BMM.fit$par[5:6]
  BMM.fit$llik=BMM.fit$value
  BMM.fit$nparams=length(guess_values)
  BMM.fit$AIC=-2*BMM.fit$value+2*length(guess_values)
  BMM.fit$AICc=BMM.fit$AIC+((2*BMM.fit$nparams*(BMM.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMM.fit$nparams-1))
  
  
  # Model BM1
  guess_values <- rep(c(1,0),each=length(vars))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BM1.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BM1",cor=FALSE)},
                   method="BFGS", control=list(fnscale=-1, maxit=5000))
  BM1.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BM1.fit$par[1:2])
  BM1.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BM1.fit$par[1:2])
  BM1.fit$theta_hum=BM1.fit$par[3:4]
  BM1.fit$theta_mix=BM1.fit$par[3:4]
  BM1.fit$llik=BM1.fit$value
  BM1.fit$nparams=length(guess_values)
  BM1.fit$AIC=-2*BM1.fit$value+2*length(guess_values)
  BM1.fit$AICc=BM1.fit$AIC+((2*BM1.fit$nparams*(BM1.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BM1.fit$nparams-1))
  
  
  # Comparative table of the different models (AICc)
  model.comparison <- data.frame(model.nb=c(1:10),
                                 model=c("OUMVA","OUMA","OUMV","OUM",
                                         "OU1","OUBM","BMOU","BMMV",
                                         "BMM","BM1"),
                                 lnL=c(OUMVA.fit$value,OUMA.fit$value,OUMV.fit$value,OUM.fit$value,
                                       OU1.fit$value,OUBM.fit$value,BMOU.fit$value,BMMV.fit$value,
                                       BMM.fit$value,BM1.fit$value),
                                 nparams=c(OUMVA.fit$nparams,OUMA.fit$nparams,OUMV.fit$nparams,OUM.fit$nparams,
                                           OU1.fit$nparams,OUBM.fit$nparams,BMOU.fit$nparams,BMMV.fit$nparams,
                                           BMM.fit$nparams,BM1.fit$nparams),
                                 conv=c(OUMVA.fit$convergence,OUMA.fit$convergence,OUMV.fit$convergence,OUM.fit$convergence,
                                        OU1.fit$convergence,OUBM.fit$convergence,BMOU.fit$convergence,BMMV.fit$convergence,
                                        BMM.fit$convergence,BM1.fit$convergence),
                                 AIC=c(OUMVA.fit$AIC,OUMA.fit$AIC,OUMV.fit$AIC,OUM.fit$AIC,
                                       OU1.fit$AIC,OUBM.fit$AIC,BMOU.fit$AIC,BMMV.fit$AIC,
                                       BMM.fit$AIC,BM1.fit$AIC),
                                 AICc=c(OUMVA.fit$AICc,OUMA.fit$AICc,OUMV.fit$AICc,OUM.fit$AICc,
                                        OU1.fit$AICc,OUBM.fit$AICc,BMOU.fit$AICc,BMMV.fit$AICc,
                                        BMM.fit$AICc,BM1.fit$AICc)
  )
  model.comparison$delta <- model.comparison$AICc-min(model.comparison$AICc)
  model.comparison$w <- exp(-0.5*model.comparison$delta) / sum(exp(-0.5*model.comparison$delta))
  model.comparison[,c(3,6:9)] <- round(model.comparison[,c(3,6:9)],3)
  
  fitted.models <- list()
  fitted.models$OUMVA <- OUMVA.fit
  fitted.models$OUMA <- OUMA.fit
  fitted.models$OUMV <- OUMV.fit
  fitted.models$OUM <- OUM.fit
  fitted.models$OU1 <- OU1.fit
  fitted.models$OUBM <- OUBM.fit
  fitted.models$BMOU <- BMOU.fit
  fitted.models$BMMV <- BMMV.fit
  fitted.models$BMM <- BMM.fit
  fitted.models$BM1 <- BM1.fit
  
  return(list(models=fitted.models,summary=model.comparison))
  
}

# Example of the function with one rep
(res.fit <- one.step.mvCOMPOUND(trees=random.trees,tree.nb=1,res.tan.spe,pollinator.data,sd.error,vars=c(1:2)))

# The model fiting on the posterior distribution
library(parallel)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir/out.txt") # Initiate cluster
nreps=200
set.seed(1234)
res.fit <- parSapply(cl,seq(1,length.out=nreps),function(c) one.step.mvCOMPOUND(trees=random.trees,tree.nb=c,res.tan.spe,pollinator.data,sd.error,vars=c(1,2)))
stopCluster(cl)
#No parallelization
#res.fit <- sapply(seq(1,length.out=nreps),function(c) one.step.mvCOMPOUND(random.trees,tree.nb=c,res.tan.spe,pollinator.data,sd.error,vars=c(1:2)))
#save(res.fit.save,file="res.fit.confirmed.Rdata")

# Same thing, but with a loop to prevent possible errors
nreps=200
iter=10
steps=nreps/iter
set.seed(1234)
no_cores <- detectCores() - 1 # Calculate the number of cores
for(step in 1:(steps-1)) {
  cat("Performing steps",(step*iter)+1,"to",((step+1)*iter)+1,"\n")
  cl <- makeCluster(no_cores,type="FORK",outfile="~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir/out.txt") # Initiate cluster
  res.fit<-NULL
  while(length(res.fit)==0){
    try(res.fit <- parSapply(cl,seq(((step*iter)+1),length.out=iter),function(c) one.step.mvCOMPOUND(trees=random.trees,tree.nb=c,res.tan.spe,pollinator.data,sd.error,vars=c(1,2))),TRUE)
    if(length(res.fit)==0) cat("  ->failed trial\n")
  }
  stopCluster(cl)
  if(step==0) res.fit.save <- res.fit
  else res.fit.save <- cbind(res.fit.save,res.fit)
}

# Summary model table
models=c("OUMVA","OUMA","OUMV","OUM","OU1","OUBM","BMOU","BMMV","BMM","BM1")
w.res.fit <- data.frame(weights=c(sapply(res.fit.save[2,],"[[","w")),models=models)

# Plotting of AICc weights
require(ggplot2)
#pdf(file="AICw.allsp.pdf",height=5,width=8)
plot <- ggplot(w.res.fit,aes(y=weights,x=models))
plot + geom_boxplot(aes(fill=models),bg="gray",outlier.size=1) + 
  ylab("Akaike weights") + xlab("Evolutionary models") + 
  ggtitle("Models support for the multivariate (PC1 & PC2) compound model") +
  theme_minimal() + theme(legend.position="none")
#dev.off()

###
# Parameter estimates by model averaging

# Model averaging - mixed-pollination

w.matrix = matrix(sapply(res.fit.save[2,],"[[","w"),dimnames=list(models),nrow=10)
w.matrix = w.matrix[c("OUMVA","OUMA","OUMV","OUM","OU1","BMOU"),]

stationary.mix.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["stationary_mix",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["stationary_mix",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["stationary_mix",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["stationary_mix",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["stationary_mix",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","BMOU")["stationary_mix",][[i]])*(w.matrix["BMOU",i]/sum(w.matrix[,i])))
  return(average)
} 
#mean
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) stationary.mix.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=2,dimnames=list(c("PC1","PC2"),c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) stationary.mix.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=2,dimnames=list(c("PC1","PC2"),c("PC1","PC2")))

halflife.mix.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["halflife_mix",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["halflife_mix",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["halflife_mix",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["halflife_mix",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["halflife_mix",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","BMOU")["halflife_mix",][[i]])*(w.matrix["BMOU",i]/sum(w.matrix[,i])))
  return(average)
} 
#mean
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) halflife.mix.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=1,dimnames=list(NULL,c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) halflife.mix.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=1,dimnames=list(NULL,c("PC1","PC2")))

theta.mix.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["theta_mix",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["theta_mix",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["theta_mix",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["theta_mix",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["theta_mix",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","BMOU")["theta_mix",][[i]])*(w.matrix["BMOU",i]/sum(w.matrix[,i])))
  return(average)
} 
#mean
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) theta.mix.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=1,dimnames=list(NULL,c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) theta.mix.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=1,dimnames=list(NULL,c("PC1","PC2")))


# Model averaging - hummingbird
w.matrix = matrix(sapply(res.fit.save[2,],"[[","w"),dimnames=list(models),nrow=10)
w.matrix = w.matrix[c("OUMVA","OUMA","OUMV","OUM","OU1","OUBM"),]

stationary.hum.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["stationary_hum",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["stationary_hum",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["stationary_hum",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["stationary_hum",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["stationary_hum",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUBM")["stationary_hum",][[i]])*(w.matrix["OUBM",i]/sum(w.matrix[,i])))
  return(average)
} 
#mean
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) stationary.hum.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=2,dimnames=list(c("PC1","PC2"),c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) stationary.hum.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=2,dimnames=list(c("PC1","PC2"),c("PC1","PC2")))

halflife.hum.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["halflife_hum",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["halflife_hum",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["halflife_hum",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["halflife_hum",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["halflife_hum",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUBM")["halflife_hum",][[i]])*(w.matrix["OUBM",i]/sum(w.matrix[,i])))
  return(average)
} 
#mean
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) halflife.hum.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=1,dimnames=list(NULL,c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) halflife.hum.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=1,dimnames=list(NULL,c("PC1","PC2")))

theta.hum.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["theta_hum",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["theta_hum",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["theta_hum",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["theta_hum",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["theta_hum",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUBM")["theta_hum",][[i]])*(w.matrix["OUBM",i]/sum(w.matrix[,i])))
  return(average)
} 
#mean
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) theta.hum.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=1,dimnames=list(NULL,c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) theta.hum.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=1,dimnames=list(NULL,c("PC1","PC2")))


# Make figure for paper

require(ggplot2)
library(grid)
library(gridExtra)
load(file="res.fit.confirmed.Rdata")
models=c("OUMVA","OUMA","OUMV","OUM","OU1","OUBM","BMOU","BMMV","BMM","BM1")
w.res.fit <- data.frame(weights=c(sapply(res.fit.save[2,],"[[","w")),models=models)
plot <- ggplot(w.res.fit,aes(y=weights,x=models))
plot1 <- plot + geom_boxplot(aes(fill=models),bg="gray",outlier.size=1) + 
  ylab("Akaike weights") + xlab("Evolutionary models") + 
  #ggtitle("A) All species (inferred syndromes)") +
  theme_minimal() + theme(legend.position="none", plot.title = element_text(hjust = -0.27))
title1 <- textGrob(
  label = "A) Species with confirmed syndromes",
  x = unit(0, "lines"), 
  y = unit(0, "lines"),
  hjust = 0, vjust = 0,
  gp = gpar(fontsize = 14))
p1 <- arrangeGrob(plot1, top = title1)

load(file="res.fit.all.Rdata")
w.res.fit <- data.frame(weights=c(sapply(res.fit.save[2,],"[[","w")),models=models)
plot <- ggplot(w.res.fit,aes(y=weights,x=models))
plot2 <- plot + geom_boxplot(aes(fill=models),bg="gray",outlier.size=1) + 
  ylab("Akaike weights") + xlab("Evolutionary models") + 
  #ggtitle("B) Species with confirmed syndromes") +
  theme_minimal() + theme(legend.position="none", plot.title = element_text(hjust = 0))
title2 <- textGrob(
  label = "B) All species (confirmed + inferred syndromes)",
  x = unit(0, "lines"), 
  y = unit(0, "lines"),
  hjust = 0, vjust = 0,
  gp = gpar(fontsize = 14))
p2 <- arrangeGrob(plot2, top = title2)

pdf("model_fitting.pdf",height=5,width=8)
grid.arrange(p1,p2,ncol=1)
dev.off()

#individually

pdf("model_fitting_confirmed.pdf",height=3,width=8)
plot1
dev.off()

pdf("model_fitting_inferred.pdf",height=3,width=8)
plot2
dev.off()



###
# END


# mvMORPH, censored model (with correlations) ------

require(mvMORPH)
source('utility_functions.R') # for the censoredtrees function

random.trees <- read.nexus("FiveThousandTrees.trees")

# Change species names to fit that of the table
attr(random.trees,"TipLabel") <- sub("G","GES_",random.trees$tip.label$tip.label)
attr(random.trees,"TipLabel") <- sub("R","RHY_",random.trees$tip.label$tip.label)

# Remove species for which we don't have data
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

# For confirmed species only
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
exclude.nodata4 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Confirmed"]=="no","CodeSpecies"])]
exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3,exclude.nodata4))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label

# For hummingbird inferred, else confirmed
exclude.nodata <- unique(as.vector(data[!(as.vector(data[,"CodeSpecies"]) %in% attr(random.trees,"TipLabel")),"CodeSpecies"]))
exclude.nodata2 <- attr(random.trees,"TipLabel")[!(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"]!="unknown","CodeSpecies"])]
exclude.nodata3 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[data[,"Pollinator"] %in% c("moth","bat"),"CodeSpecies"])]
exclude.nodata4 <- attr(random.trees,"TipLabel")[(attr(random.trees,"TipLabel") %in% data[((data[,"Confirmed"]=="no") & (data[,"Pollinator"] == "mixed-pollination")),"CodeSpecies"])]
exclude <- unique(c(exclude.nodata,exclude.nodata2,exclude.nodata3,exclude.nodata4))
random.trees<-lapply(random.trees,drop.tip,tip=exclude)
class(random.trees)<-"multiPhylo"
attr(random.trees,"TipLabel") <- random.trees[[1]]$tip.label


# Order data according to tree tips
# Calculate mean PC coordinates per species
species <- unique(data[,'CodeSpecies'])
res.tan.spe<-matrix(data=NA,nrow=length(species),ncol=64)
for (i in 1:length(species)){
  if(length(data[data[,'CodeSpecies']==species[i],1])==1) {
    res.tan.spe[i,]<-res.pca$x[data[,'CodeSpecies']==species[i],]
  }
  else 
    res.tan.spe[i,]<-apply(res.pca$x[data[,'CodeSpecies']==species[i],],2,mean)
}
rownames(res.tan.spe) <- species
res.tan.spe <- res.tan.spe[match(attr(random.trees,"TipLabel"),rownames(res.tan.spe)),]
colnames(res.tan.spe) = sapply(1:ncol(res.tan.spe),function(c) paste("PC",c,sep=""))

# Vector of pollinator data
pollinator.data <- data[match(rownames(res.tan.spe),data[,'CodeSpecies']),'Pollinator']
pollinator.data <- as.factor(as.vector(pollinator.data))
names(pollinator.data) <- data[match(rownames(res.tan.spe),data[,'CodeSpecies']),'CodeSpecies']


###
# Calculate intraspecific standard error to include 
# as error term in estimates
data.spe.gen <- res.tan.spe[pollinator.data == "mixed-pollination",1:3]
data.ind.gen <- res.pca$x[data$Pollinator == "mixed-pollination",1:3]
rownames(data.ind.gen) <- data$CodeSpecies[data$Pollinator == "mixed-pollination"]
sd.error.gen <- matrix(nrow=nrow(data.spe.gen),ncol=3)
rownames(sd.error.gen) <- rownames(data.spe.gen)
colnames(sd.error.gen) <- colnames(data.spe.gen)
for (i in 1:nrow(sd.error.gen)) {
  temp <- data.ind.gen[rownames(data.ind.gen) == rownames(data.spe.gen)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.gen[i,1] <- sd.error.gen[i,2] <- sd.error.gen[i,3] <- NA
    next
  }
  sd.error.gen[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.gen[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                          
  sd.error.gen[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                          
}
gen.error <- mean(sd.error.gen, na.rm=TRUE)
# Replace NAs by mean
sd.error.gen[is.na(sd.error.gen)] <- gen.error

# Hummingbird specialists
data.spe.hum <- res.tan.spe[pollinator.data == "hummingbird",1:3]
data.ind.hum <- res.pca$x[data$Pollinator == "hummingbird",1:3]
rownames(data.ind.hum) <- data$CodeSpecies[data$Pollinator == "hummingbird"]
sd.error.hum <- matrix(nrow=nrow(data.spe.hum),ncol=3)
rownames(sd.error.hum) <- rownames(data.spe.hum)
colnames(sd.error.hum) <- colnames(data.spe.hum)
for (i in 1:nrow(sd.error.hum)) {
  temp <- data.ind.hum[rownames(data.ind.hum) == rownames(data.spe.hum)[i],]
  if (length(as.vector(temp))==3) {
    sd.error.hum[i,1] <- sd.error.hum[i,2] <- sd.error.hum[i,3] <- NA
    next
  }
  sd.error.hum[i,1] <- sd(temp[,1])/sqrt(nrow(temp))
  sd.error.hum[i,2] <- sd(temp[,2])/sqrt(nrow(temp))                           
  sd.error.hum[i,3] <- sd(temp[,3])/sqrt(nrow(temp))                           
}
hum.error <- mean(sd.error.hum, na.rm=TRUE)
# Replace NAs by mean
sd.error.hum[is.na(sd.error.hum)] <- hum.error

# error
sd.error <- rbind(sd.error.hum,sd.error.gen)
sd.error <- sd.error[attr(random.trees,"TipLabel"),]


####
#
# Functions to obtain the models for each subtree (getMODELS)
#   and to get the compound model over all subtrees (mvCOMPOUND)
#


# mvCOMPOUND, posterior distribution ------------------------------------------------

one.step.mvCOMPOUND <- function(trees,tree.nb,res.tan.spe,pollinator.data,
                                sd.error,vars=c(1:2)) {
  require(phytools)
  require(mvMORPH)
  source('utility_functions.R') # for the censoredtrees function
  
  cat("\nTree:",tree.nb,"\n")
  
  atree <- trees[[tree.nb]]  
  
  #Stochastic mapping
  set.seed(1234)
  chartrees <- make.simmap(atree, pollinator.data,model="ER",nsim=201)
  res_simmap <- describe.simmap(chartrees, plot = FALSE)
  
  if(any(res_simmap$ace[,1]==res_simmap$ace[,2])) {
    cat("\nSkipping tree",tree.nb,". Equal likelihood at nodes.\n\n")
    return(list(models=NULL,summary=NULL))
  }
  
  # Get ML state at each node
  anc_node<-factor(character(nrow(res_simmap$ace)),levels=levels(pollinator.data))
  for(i in 1:length(anc_node)) {
    anc_node[i] <- levels(pollinator.data)[res_simmap$ace[i,]==max(res_simmap$ace[i,])]
  }
  atree$node.label <- anc_node
  states <- c(as.vector(pollinator.data),as.vector(anc_node))
  
  #create mapping table (node number -> syndrome)
  mapping.table <- data.frame(node=seq(1,length(states)),syndrome=states)
  
  # Make censored trees
  res <- censoredtrees(tree=atree, map=mapping.table, combine.subtrees=FALSE)
  
  hum.trees <- res[[1]]
  mix.trees <- res[[2]]
  if(length(hum.trees)==0 | length(mix.trees)==0) next
  trees <- c(hum.trees, mix.trees)
  regimes <- rep(c(1,2),times=c(length(hum.trees),length(mix.trees)))
  
  ####
  # Fit models
  
  # OUMVA
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(5,1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes,models=c("OU","OU"))
  OUMVA.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMVA",cor=FALSE)},
                     method="BFGS", control=list(fnscale=-1, maxit=20000))
  OUMVA.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMVA.fit$par[1:2])$A 
  OUMVA.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMVA.fit$par[3:4])
  OUMVA.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMVA.fit$par[7:8])$A 
  OUMVA.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMVA.fit$par[9:10])
  OUMVA.fit$theta_hum=OUMVA.fit$par[5:6]
  OUMVA.fit$theta_mix=OUMVA.fit$par[11:12]
  hum.ou <- list(alpha=OUMVA.fit$alpha_hum,sigma=OUMVA.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMVA.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMVA.fit$alpha_mix,sigma=OUMVA.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMVA.fit$stationary_mix=stationary(mix.ou)
  OUMVA.fit$halflife_hum=halflife(hum.ou)
  OUMVA.fit$halflife_mix=halflife(mix.ou)
  OUMVA.fit$llik=OUMVA.fit$value
  OUMVA.fit$nparams=length(guess_values)
  OUMVA.fit$AIC=-2*OUMVA.fit$value+2*length(guess_values)
  OUMVA.fit$AICc=OUMVA.fit$AIC+((2*OUMVA.fit$nparams*(OUMVA.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMVA.fit$nparams-1))
  
  
  # OUMA (different theta, different alpha, shared sigma)
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(5,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUMA.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMA",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUMA.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMA.fit$par[1:2])$A 
  OUMA.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMA.fit$par[3:4])
  OUMA.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMA.fit$par[7:8])$A 
  OUMA.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMA.fit$par[3:4])
  OUMA.fit$theta_hum=OUMA.fit$par[5:6]
  OUMA.fit$theta_mix=OUMA.fit$par[9:10]
  hum.ou <- list(alpha=OUMA.fit$alpha_hum,sigma=OUMA.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMA.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMA.fit$alpha_mix,sigma=OUMA.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMA.fit$stationary_mix=stationary(mix.ou)
  OUMA.fit$halflife_hum=halflife(hum.ou)
  OUMA.fit$halflife_mix=halflife(mix.ou)
  OUMA.fit$llik=OUMA.fit$value
  OUMA.fit$nparams=length(guess_values)
  OUMA.fit$AIC=-2*OUMA.fit$value+2*length(guess_values)
  OUMA.fit$AICc=OUMA.fit$AIC+((2*OUMA.fit$nparams*(OUMA.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMA.fit$nparams-1))
  
  
  # OUMV (different theta, different sigma, shared alpha)
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUMV.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMV",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUMV.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMV.fit$par[1:2])$A 
  OUMV.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMV.fit$par[3:4])
  OUMV.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMV.fit$par[1:2])$A 
  OUMV.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMV.fit$par[7:8])
  OUMV.fit$theta_hum=OUMV.fit$par[5:6]
  OUMV.fit$theta_mix=OUMV.fit$par[9:10]
  hum.ou <- list(alpha=OUMV.fit$alpha_hum,sigma=OUMV.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMV.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMV.fit$alpha_mix,sigma=OUMV.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMV.fit$stationary_mix=stationary(mix.ou)
  OUMV.fit$halflife_hum=halflife(hum.ou)
  OUMV.fit$halflife_mix=halflife(mix.ou)
  OUMV.fit$llik=OUMV.fit$value
  OUMV.fit$nparams=length(guess_values)
  OUMV.fit$AIC=-2*OUMV.fit$value+2*length(guess_values)
  OUMV.fit$AICc=OUMV.fit$AIC+((2*OUMV.fit$nparams*(OUMV.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMV.fit$nparams-1))
  
  
  # OUM
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUM.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUM",cor=FALSE)},
                   method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUM.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUM.fit$par[1:2])$A 
  OUM.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUM.fit$par[3:4])
  OUM.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUM.fit$par[1:2])$A 
  OUM.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUM.fit$par[3:4])
  OUM.fit$theta_hum=OUM.fit$par[5:6]
  OUM.fit$theta_mix=OUM.fit$par[7:8]
  hum.ou <- list(alpha=OUM.fit$alpha_hum,sigma=OUM.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUM.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUM.fit$alpha_mix,sigma=OUM.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUM.fit$stationary_mix=stationary(mix.ou)
  OUM.fit$halflife_hum=halflife(hum.ou)
  OUM.fit$halflife_mix=halflife(mix.ou)
  OUM.fit$llik=OUM.fit$value
  OUM.fit$nparams=length(guess_values)
  OUM.fit$AIC=-2*OUM.fit$value+2*length(guess_values)
  OUM.fit$AICc=OUM.fit$AIC+((2*OUM.fit$nparams*(OUM.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUM.fit$nparams-1))
  
  
  # Model OU1
  guess_values <- rep(c(5,1,0),each=length(vars))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OU1.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OU1",cor=FALSE)},
                   method="BFGS", control=list(fnscale=-1, maxit=10000))
  OU1.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OU1.fit$par[1:2])$A 
  OU1.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OU1.fit$par[3:4])
  OU1.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OU1.fit$par[1:2])$A 
  OU1.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OU1.fit$par[3:4])
  OU1.fit$theta_hum=OU1.fit$par[5:6]
  OU1.fit$theta_mix=OU1.fit$par[5:6]
  hum.ou <- list(alpha=OU1.fit$alpha_hum,sigma=OU1.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OU1.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OU1.fit$alpha_mix,sigma=OU1.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OU1.fit$stationary_mix=stationary(mix.ou)
  OU1.fit$halflife_hum=halflife(hum.ou)
  OU1.fit$halflife_mix=halflife(mix.ou)
  OU1.fit$llik=OU1.fit$value
  OU1.fit$nparams=length(guess_values)
  OU1.fit$AIC=-2*OU1.fit$value+2*length(guess_values)
  OU1.fit$AICc=OU1.fit$AIC+((2*OU1.fit$nparams*(OU1.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OU1.fit$nparams-1))
  
  
  # Model OUBM
  guess_values <- c(rep(c(5,1,0),each=length(vars)),rep(c(1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","BM"))
  OUBM.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUBM",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=5000))
  OUBM.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUBM.fit$par[1:2])$A 
  OUBM.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUBM.fit$par[3:4])
  OUBM.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUBM.fit$par[7:8])
  OUBM.fit$theta_hum=OUBM.fit$par[5:6]
  OUBM.fit$theta_mix=OUBM.fit$par[9:10]
  hum.ou <- list(alpha=OUBM.fit$alpha_hum,sigma=OUBM.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUBM.fit$stationary_hum=stationary(hum.ou)
  OUBM.fit$halflife_hum=halflife(hum.ou)
  OUBM.fit$llik=OUBM.fit$value
  OUBM.fit$nparams=length(guess_values)
  OUBM.fit$AIC=-2*OUBM.fit$value+2*length(guess_values)
  OUBM.fit$AICc=OUBM.fit$AIC+((2*OUBM.fit$nparams*(OUBM.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUBM.fit$nparams-1))
  
  
  # Model BMOU
  guess_values <- c(rep(c(1,0),each=length(vars)),rep(c(5,1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","OU"))
  BMOU.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMOU",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMOU.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMOU.fit$par[1:2])
  BMOU.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(BMOU.fit$par[5:6])$A 
  BMOU.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMOU.fit$par[7:8])
  BMOU.fit$theta_hum=BMOU.fit$par[3:4]
  BMOU.fit$theta_mix=BMOU.fit$par[9:10]
  mix.ou <- list(alpha=BMOU.fit$alpha_mix,sigma=BMOU.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  BMOU.fit$stationary_mix=stationary(mix.ou)
  BMOU.fit$halflife_mix=halflife(mix.ou)
  BMOU.fit$llik=BMOU.fit$value
  BMOU.fit$nparams=length(guess_values)
  BMOU.fit$AIC=-2*BMOU.fit$value+2*length(guess_values)
  BMOU.fit$AICc=BMOU.fit$AIC+((2*BMOU.fit$nparams*(BMOU.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMOU.fit$nparams-1))
  
  
  # Model BMMV
  guess_values <- c(rep(c(1,0),each=length(vars)),rep(c(1,0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BMMV.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMMV",cor=FALSE)},
                    method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMMV.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMMV.fit$par[1:2])
  BMMV.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMMV.fit$par[5:6])
  BMMV.fit$theta_hum=BMMV.fit$par[3:4]
  BMMV.fit$theta_mix=BMMV.fit$par[7:8]
  BMMV.fit$llik=BMMV.fit$value
  BMMV.fit$nparams=length(guess_values)
  BMMV.fit$AIC=-2*BMMV.fit$value+2*length(guess_values)
  BMMV.fit$AICc=BMMV.fit$AIC+((2*BMMV.fit$nparams*(BMMV.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMMV.fit$nparams-1))
  
  
  # Model BMM (different theta, shared sigma)
  guess_values <- c(rep(c(1,0),each=length(vars)),rep(c(0),each=length(vars)))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BMM.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMM",cor=FALSE)},
                   method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMM.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMM.fit$par[1:2])
  BMM.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMM.fit$par[1:2])
  BMM.fit$theta_hum=BMM.fit$par[3:4]
  BMM.fit$theta_mix1=BMM.fit$par[5:6]
  BMM.fit$llik=BMM.fit$value
  BMM.fit$nparams=length(guess_values)
  BMM.fit$AIC=-2*BMM.fit$value+2*length(guess_values)
  BMM.fit$AICc=BMM.fit$AIC+((2*BMM.fit$nparams*(BMM.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMM.fit$nparams-1))
  
  
  # Model BM1
  guess_values <- rep(c(1,0),each=length(vars))
  themodels <- getMODELS(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BM1.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BM1",cor=FALSE)},
                   method="BFGS", control=list(fnscale=-1, maxit=5000))
  BM1.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BM1.fit$par[1:2])
  BM1.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BM1.fit$par[1:2])
  BM1.fit$theta_hum=BM1.fit$par[3:4]
  BM1.fit$theta_mix1=BM1.fit$par[3:4]
  BM1.fit$llik=BM1.fit$value
  BM1.fit$nparams=length(guess_values)
  BM1.fit$AIC=-2*BM1.fit$value+2*length(guess_values)
  BM1.fit$AICc=BM1.fit$AIC+((2*BM1.fit$nparams*(BM1.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BM1.fit$nparams-1))

  # Models with correlations
  
  # OUMVA
  guess_values <- c(rep(c(5,1),each=(length(vars)+1)),rep(0,each=length(vars)),rep(c(5,1),each=(length(vars)+1)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes,models=c("OU","OU"))
  OUMVAcor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMVA",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=20000))
  OUMVAcor.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMVAcor.fit$par[1:3])$A 
  OUMVAcor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMVAcor.fit$par[4:6])
  OUMVAcor.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMVAcor.fit$par[9:11])$A 
  OUMVAcor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMVAcor.fit$par[12:14])
  OUMVAcor.fit$theta_hum=OUMVAcor.fit$par[7:8]
  OUMVAcor.fit$theta_mix=OUMVAcor.fit$par[15:16]
  hum.ou <- list(alpha=OUMVAcor.fit$alpha_hum,sigma=OUMVAcor.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMVAcor.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMVAcor.fit$alpha_mix,sigma=OUMVAcor.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMVAcor.fit$stationary_mix=stationary(mix.ou)
  OUMVAcor.fit$halflife_hum=halflife(hum.ou)
  OUMVAcor.fit$halflife_mix=halflife(mix.ou)
  OUMVAcor.fit$llik=OUMVAcor.fit$value
  OUMVAcor.fit$nparams=length(guess_values)
  OUMVAcor.fit$AIC=-2*OUMVAcor.fit$value+2*length(guess_values)
  OUMVAcor.fit$AICc=OUMVAcor.fit$AIC+((2*OUMVAcor.fit$nparams*(OUMVAcor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMVAcor.fit$nparams-1))
  
  
  # OUMA (different theta, different alpha, shared sigma)
  guess_values <- c(rep(c(5,1),each=(length(vars)+1)),rep(0,each=length(vars)),rep(5,each=(length(vars)+1)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUMAcor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMA",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUMAcor.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMAcor.fit$par[1:3])$A 
  OUMAcor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMAcor.fit$par[4:6])
  OUMAcor.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMAcor.fit$par[9:11])$A 
  OUMAcor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMAcor.fit$par[4:6])
  OUMAcor.fit$theta_hum=OUMAcor.fit$par[7:8]
  OUMAcor.fit$theta_mix=OUMAcor.fit$par[12:13]
  hum.ou <- list(alpha=OUMAcor.fit$alpha_hum,sigma=OUMAcor.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMAcor.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMAcor.fit$alpha_mix,sigma=OUMAcor.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMAcor.fit$stationary_mix=stationary(mix.ou)
  OUMAcor.fit$halflife_hum=halflife(hum.ou)
  OUMAcor.fit$halflife_mix=halflife(mix.ou)
  OUMAcor.fit$llik=OUMAcor.fit$value
  OUMAcor.fit$nparams=length(guess_values)
  OUMAcor.fit$AIC=-2*OUMAcor.fit$value+2*length(guess_values)
  OUMAcor.fit$AICc=OUMAcor.fit$AIC+((2*OUMAcor.fit$nparams*(OUMAcor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMAcor.fit$nparams-1))
  
  
  # OUMV (different theta, different sigma, shared alpha)
  guess_values <- c(rep(c(5,1),each=(length(vars)+1)),rep(0,each=length(vars)),rep(1,each=(length(vars)+1)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUMVcor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUMV",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUMVcor.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMVcor.fit$par[1:3])$A 
  OUMVcor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMVcor.fit$par[4:6])
  OUMVcor.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMVcor.fit$par[1:3])$A 
  OUMVcor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMVcor.fit$par[9:11])
  OUMVcor.fit$theta_hum=OUMVcor.fit$par[7:8]
  OUMVcor.fit$theta_mix=OUMVcor.fit$par[12:13]
  hum.ou <- list(alpha=OUMVcor.fit$alpha_hum,sigma=OUMVcor.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMVcor.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMVcor.fit$alpha_mix,sigma=OUMVcor.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMVcor.fit$stationary_mix=stationary(mix.ou)
  OUMVcor.fit$halflife_hum=halflife(hum.ou)
  OUMVcor.fit$halflife_mix=halflife(mix.ou)
  OUMVcor.fit$llik=OUMVcor.fit$value
  OUMVcor.fit$nparams=length(guess_values)
  OUMVcor.fit$AIC=-2*OUMVcor.fit$value+2*length(guess_values)
  OUMVcor.fit$AICc=OUMVcor.fit$AIC+((2*OUMVcor.fit$nparams*(OUMVcor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMVcor.fit$nparams-1))
  
  
  # OUM
  guess_values <- c(rep(c(5,1),each=(length(vars)+1)),rep(0,each=length(vars)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OUMcor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUM",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=10000))
  OUMcor.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUMcor.fit$par[1:3])$A 
  OUMcor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUMcor.fit$par[4:6])
  OUMcor.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OUMcor.fit$par[1:3])$A 
  OUMcor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUMcor.fit$par[4:6])
  OUMcor.fit$theta_hum=OUMcor.fit$par[7:8]
  OUMcor.fit$theta_mix=OUMcor.fit$par[9:10]
  hum.ou <- list(alpha=OUMcor.fit$alpha_hum,sigma=OUMcor.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUMcor.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OUMcor.fit$alpha_mix,sigma=OUMcor.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OUMcor.fit$stationary_mix=stationary(mix.ou)
  OUMcor.fit$halflife_hum=halflife(hum.ou)
  OUMcor.fit$halflife_mix=halflife(mix.ou)
  OUMcor.fit$llik=OUMcor.fit$value
  OUMcor.fit$nparams=length(guess_values)
  OUMcor.fit$AIC=-2*OUMcor.fit$value+2*length(guess_values)
  OUMcor.fit$AICc=OUMcor.fit$AIC+((2*OUMcor.fit$nparams*(OUMcor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUMcor.fit$nparams-1))
  
  
  # Model OU1
  guess_values <- c(rep(c(5,1),each=(length(vars)+1)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","OU"))
  OU1cor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OU1",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=10000))
  OU1cor.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OU1cor.fit$par[1:3])$A 
  OU1cor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OU1cor.fit$par[4:6])
  OU1cor.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(OU1cor.fit$par[1:3])$A 
  OU1cor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OU1cor.fit$par[4:6])
  OU1cor.fit$theta_hum=OU1cor.fit$par[7:8]
  OU1cor.fit$theta_mix=OU1cor.fit$par[7:8]
  hum.ou <- list(alpha=OU1cor.fit$alpha_hum,sigma=OU1cor.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OU1cor.fit$stationary_hum=stationary(hum.ou)
  mix.ou <- list(alpha=OU1cor.fit$alpha_mix,sigma=OU1cor.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  OU1cor.fit$stationary_mix=stationary(mix.ou)
  OU1cor.fit$halflife_hum=halflife(hum.ou)
  OU1cor.fit$halflife_mix=halflife(mix.ou)
  OU1cor.fit$llik=OU1cor.fit$value
  OU1cor.fit$nparams=length(guess_values)
  OU1cor.fit$AIC=-2*OU1cor.fit$value+2*length(guess_values)
  OU1cor.fit$AICc=OU1cor.fit$AIC+((2*OU1cor.fit$nparams*(OU1cor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OU1cor.fit$nparams-1))
  
  
  # Model OUBM
  guess_values <- c(rep(c(5,1),each=(length(vars)+1)),rep(0,each=length(vars)),rep(1,each=(length(vars)+1)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("OU","BM"))
  OUBMcor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="OUBM",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=5000))
  OUBMcor.fit$alpha_hum=themodels[[match(1,regimes)]]$param$alphafun(OUBMcor.fit$par[1:3])$A 
  OUBMcor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(OUBMcor.fit$par[4:6])
  OUBMcor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(OUBMcor.fit$par[9:11])
  OUBMcor.fit$theta_hum=OUBMcor.fit$par[7:8]
  OUBMcor.fit$theta_mix=OUBMcor.fit$par[12:13]
  hum.ou <- list(alpha=OUBMcor.fit$alpha_hum,sigma=OUBMcor.fit$sigma_hum);class(hum.ou)<-c("mvmorph","mvmorph.ou")
  OUBMcor.fit$stationary_hum=stationary(hum.ou)
  OUBMcor.fit$halflife_hum=halflife(hum.ou)
  OUBMcor.fit$llik=OUBMcor.fit$value
  OUBMcor.fit$nparams=length(guess_values)
  OUBMcor.fit$AIC=-2*OUBMcor.fit$value+2*length(guess_values)
  OUBMcor.fit$AICc=OUBMcor.fit$AIC+((2*OUBMcor.fit$nparams*(OUBMcor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-OUBMcor.fit$nparams-1))
  
  
  # Model BMOU
  guess_values <- c(rep(1,each=(length(vars)+1)),rep(0,each=length(vars)),rep(c(5,1),each=(length(vars)+1)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","OU"))
  BMOUcor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMOU",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMOUcor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMOUcor.fit$par[1:3])
  BMOUcor.fit$alpha_mix=themodels[[match(2,regimes)]]$param$alphafun(BMOUcor.fit$par[6:8])$A 
  BMOUcor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMOUcor.fit$par[9:11])
  BMOUcor.fit$theta_hum=BMOUcor.fit$par[4:5]
  BMOUcor.fit$theta_mix=BMOUcor.fit$par[12:13]
  mix.ou <- list(alpha=BMOUcor.fit$alpha_mix,sigma=BMOUcor.fit$sigma_mix);class(mix.ou)<-c("mvmorph","mvmorph.ou")
  BMOUcor.fit$stationary_mix=stationary(mix.ou)
  BMOUcor.fit$halflife_mix=halflife(mix.ou)
  BMOUcor.fit$llik=BMOUcor.fit$value
  BMOUcor.fit$nparams=length(guess_values)
  BMOUcor.fit$AIC=-2*BMOUcor.fit$value+2*length(guess_values)
  BMOUcor.fit$AICc=BMOUcor.fit$AIC+((2*BMOUcor.fit$nparams*(BMOUcor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMOUcor.fit$nparams-1))
  
  
  # Model BMMV
  guess_values <- c(rep(1,each=(length(vars)+1)),rep(0,each=length(vars)),rep(1,each=(length(vars)+1)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BMMVcor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMMV",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMMVcor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMMVcor.fit$par[1:3])
  BMMVcor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMMVcor.fit$par[6:8])
  BMMVcor.fit$theta_hum=BMMVcor.fit$par[4:5]
  BMMVcor.fit$theta_mix=BMMVcor.fit$par[9:10]
  BMMVcor.fit$llik=BMMVcor.fit$value
  BMMVcor.fit$nparams=length(guess_values)
  BMMVcor.fit$AIC=-2*BMMVcor.fit$value+2*length(guess_values)
  BMMVcor.fit$AICc=BMMVcor.fit$AIC+((2*BMMVcor.fit$nparams*(BMMVcor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMMVcor.fit$nparams-1))
  
  
  # Model BMM (different theta, shared sigma)
  guess_values <- c(rep(1,each=(length(vars)+1)),rep(0,each=length(vars)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BMMcor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BMM",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=5000))
  BMMcor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BMMcor.fit$par[1:3])
  BMMcor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BMMcor.fit$par[1:3])
  BMMcor.fit$theta_hum=BMMcor.fit$par[4:5]
  BMMcor.fit$theta_mix=BMMcor.fit$par[6:7]
  BMMcor.fit$llik=BMMcor.fit$value
  BMMcor.fit$nparams=length(guess_values)
  BMMcor.fit$AIC=-2*BMMcor.fit$value+2*length(guess_values)
  BMMcor.fit$AICc=BMMcor.fit$AIC+((2*BMMcor.fit$nparams*(BMMcor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BMMcor.fit$nparams-1))
  
  
  # Model BM1
  guess_values <- c(rep(1,each=(length(vars)+1)),rep(0,each=length(vars)))
  themodels <- getMODELScor(trees,data=res.tan.spe[,vars,drop=FALSE],error=sd.error[,vars,drop=FALSE]^2,regimes=regimes,models=c("BM","BM"))
  BM1cor.fit <- optim(guess_values, function(par){mvCOMPOUND(par,themodels,regimes=regimes,model="BM1",cor=TRUE)},method="BFGS", control=list(fnscale=-1, maxit=5000))
  BM1cor.fit$sigma_hum=themodels[[match(1,regimes)]]$param$sigmafun(BM1cor.fit$par[1:3])
  BM1cor.fit$sigma_mix=themodels[[match(2,regimes)]]$param$sigmafun(BM1cor.fit$par[1:3])
  BM1cor.fit$theta_hum=BM1cor.fit$par[4:5]
  BM1cor.fit$theta_mix=BM1cor.fit$par[4:5]
  BM1cor.fit$llik=BM1cor.fit$value
  BM1cor.fit$nparams=length(guess_values)
  BM1cor.fit$AIC=-2*BM1cor.fit$value+2*length(guess_values)
  BM1cor.fit$AICc=BM1cor.fit$AIC+((2*BM1cor.fit$nparams*(BM1cor.fit$nparams-1))/((nrow(res.tan.spe)*length(vars))-BM1cor.fit$nparams-1))
  
  
  
  # Comparative table of the different models (AICc)
  model.comparison <- data.frame(model.nb=c(1:10),
                                 model=c("OUMVA","OUMA","OUMV","OUM",
                                         "OU1","OUBM","BMOU","BMMV",
                                         "BMM","BM1",
                                         "OUMVAcor","OUMAcor","OUMVcor","OUMcor",
                                         "OU1cor","OUBMcor","BMOUcor","BMMVcor",
                                         "BMMcor","BM1cor"),
                                 lnL=c(OUMVA.fit$value,OUMA.fit$value,OUMV.fit$value,OUM.fit$value,
                                       OU1.fit$value,OUBM.fit$value,BMOU.fit$value,BMMV.fit$value,
                                       BMM.fit$value,BM1.fit$value,
                                       OUMVAcor.fit$value,OUMAcor.fit$value,OUMVcor.fit$value,OUMcor.fit$value,
                                       OU1cor.fit$value,OUBMcor.fit$value,BMOUcor.fit$value,BMMVcor.fit$value,
                                       BMMcor.fit$value,BM1cor.fit$value),
                                 nparams=c(OUMVA.fit$nparams,OUMA.fit$nparams,OUMV.fit$nparams,OUM.fit$nparams,
                                           OU1.fit$nparams,OUBM.fit$nparams,BMOU.fit$nparams,BMMV.fit$nparams,
                                           BMM.fit$nparams,BM1.fit$nparams,
                                           OUMVAcor.fit$nparams,OUMAcor.fit$nparams,OUMVcor.fit$nparams,OUMcor.fit$nparams,
                                           OU1cor.fit$nparams,OUBMcor.fit$nparams,BMOUcor.fit$nparams,BMMVcor.fit$nparams,
                                           BMMcor.fit$nparams,BM1cor.fit$nparams),
                                 conv=c(OUMVA.fit$convergence,OUMA.fit$convergence,OUMV.fit$convergence,OUM.fit$convergence,
                                        OU1.fit$convergence,OUBM.fit$convergence,BMOU.fit$convergence,BMMV.fit$convergence,
                                        BMM.fit$convergence,BM1.fit$convergence,
                                        OUMVAcor.fit$convergence,OUMAcor.fit$convergence,OUMVcor.fit$convergence,OUMcor.fit$convergence,
                                        OU1cor.fit$convergence,OUBMcor.fit$convergence,BMOUcor.fit$convergence,BMMVcor.fit$convergence,
                                        BMMcor.fit$convergence,BM1cor.fit$convergence),
                                 AIC=c(OUMVA.fit$AIC,OUMA.fit$AIC,OUMV.fit$AIC,OUM.fit$AIC,
                                       OU1.fit$AIC,OUBM.fit$AIC,BMOU.fit$AIC,BMMV.fit$AIC,
                                       BMM.fit$AIC,BM1.fit$AIC,
                                       OUMVAcor.fit$AIC,OUMAcor.fit$AIC,OUMVcor.fit$AIC,OUMcor.fit$AIC,
                                       OU1cor.fit$AIC,OUBMcor.fit$AIC,BMOUcor.fit$AIC,BMMVcor.fit$AIC,
                                       BMMcor.fit$AIC,BM1cor.fit$AIC),
                                 AICc=c(OUMVA.fit$AICc,OUMA.fit$AICc,OUMV.fit$AICc,OUM.fit$AICc,
                                        OU1.fit$AICc,OUBM.fit$AICc,BMOU.fit$AICc,BMMV.fit$AICc,
                                        BMM.fit$AICc,BM1.fit$AICc,
                                        OUMVAcor.fit$AICc,OUMAcor.fit$AICc,OUMVcor.fit$AICc,OUMcor.fit$AICc,
                                        OU1cor.fit$AICc,OUBMcor.fit$AICc,BMOUcor.fit$AICc,BMMVcor.fit$AICc,
                                        BMMcor.fit$AICc,BM1cor.fit$AICc)
  )
  model.comparison$delta <- model.comparison$AICc-min(model.comparison$AICc)
  model.comparison$w <- exp(-0.5*model.comparison$delta) / sum(exp(-0.5*model.comparison$delta))
  model.comparison[,c(3,6:9)] <- round(model.comparison[,c(3,6:9)],3)
  
  fitted.models <- list()
  fitted.models$OUMVA <- OUMVA.fit
  fitted.models$OUMA <- OUMA.fit
  fitted.models$OUMV <- OUMV.fit
  fitted.models$OUM <- OUM.fit
  fitted.models$OU1 <- OU1.fit
  fitted.models$OUBM <- OUBM.fit
  fitted.models$BMOU <- BMOU.fit
  fitted.models$BMMV <- BMMV.fit
  fitted.models$BMM <- BMM.fit
  fitted.models$BM1 <- BM1.fit
  fitted.models$OUMVAcor <- OUMVAcor.fit
  fitted.models$OUMAcor <- OUMAcor.fit
  fitted.models$OUMVcor <- OUMVcor.fit
  fitted.models$OUMcor <- OUMcor.fit
  fitted.models$OU1cor <- OU1cor.fit
  fitted.models$OUBMcor <- OUBMcor.fit
  fitted.models$BMOUcor <- BMOUcor.fit
  fitted.models$BMMVcor <- BMMVcor.fit
  fitted.models$BMMcor <- BMMcor.fit
  fitted.models$BM1cor <- BM1cor.fit
  
  return(list(models=fitted.models,summary=model.comparison))
  
}

# Example of the function with one rep
(res.fit <- one.step.mvCOMPOUND(random.trees,tree.nb=140,res.tan.spe,pollinator.data,sd.error,vars=c(1:2)))

# The simulations
library(parallel)
no_cores <- detectCores() - 1 # Calculate the number of cores
cl <- makeCluster(no_cores,type="FORK",outfile="~/Documents/gesneria/papers/flower_evolution/AmNat/suppdata_working_dir/out.txt") # Initiate cluster
nreps=30
components=c(1:2)
#components="PC2"
set.seed(1234)
res.fit <- parSapply(cl,seq(1,length.out=nreps),function(c) one.step.mvCOMPOUND(random.trees,tree.nb=c,res.tan.spe,pollinator.data,sd.error,vars=c(1,2)))
stopCluster(cl)
#No parallelization
res.fit <- sapply(seq(126,length.out=nreps),function(c) one.step.mvCOMPOUND(random.trees,tree.nb=c,res.tan.spe,pollinator.data,sd.error,vars=c(1:2)))
#save(res.fit,file="res.fit.confirmed.Rdata")

#summary
models=c("OUMVA","OUMA","OUMV","OUM","OU1","OUBM","BMOU","BMMV","BMM","BM1",
         "OUMVAcor","OUMAcor","OUMVcor","OUMcor","OU1cor","OUBMcor","BMOUcor","BMMVcor","BMMcor","BM1cor")
w.res.fit <- data.frame(weights=c(sapply(res.fit[2,],"[[","w")),models=models)
#w.res.fit <- data.frame(weights=unlist(sapply(sapply(res.fit,"[[",2),"[[","w")),models=models)

require(ggplot2)
pdf(file="AICw.mixconf.pdf",height=5,width=8)
plot <- ggplot(w.res.fit,aes(y=weights,x=models))
plot + geom_boxplot(aes(fill=models),bg="gray",outlier.size=1) + 
  ylab("Akaike weights") + xlab("Evolutionary models") + 
  ggtitle("Models support for the multivariate (PC1 & PC2) compound model") +
  theme_minimal() + theme(legend.position="none") + coord_flip()
dev.off()

# Model averaging - mixed-pollination
w.matrix = matrix(sapply(res.fit.save[2,],"[[","w"),dimnames=list(models),nrow=20)
w.matrix = w.matrix[c("OUMVA","OUMA","OUMV","OUM","OU1","BMOU"),]

stationary.mix.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["stationary_mix",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["stationary_mix",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["stationary_mix",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["stationary_mix",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["stationary_mix",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","BMOU")["stationary_mix",][[i]])*(w.matrix["BMOU",i]/sum(w.matrix[,i])))
  return(average)
} 
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) stationary.mix.model.averaging(res.fit, w.matrix, c)),1,mean),nrow=2,dimnames=list(c("PC1","PC2"),c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) stationary.mix.model.averaging(res.fit, w.matrix, c)),1,sd),nrow=2,dimnames=list(c("PC1","PC2"),c("PC1","PC2")))

halflife.mix.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["halflife_mix",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["halflife_mix",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["halflife_mix",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["halflife_mix",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["halflife_mix",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i])))
  return(average)
} 
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) halflife.mix.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=1,dimnames=list(NULL,c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) halflife.mix.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=1,dimnames=list(NULL,c("PC1","PC2")))

stationary.hum.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["stationary_hum",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["stationary_hum",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["stationary_hum",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["stationary_hum",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["stationary_hum",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i])))
  return(average)
} 
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) stationary.hum.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=2,dimnames=list(c("PC1","PC2"),c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) stationary.hum.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=2,dimnames=list(c("PC1","PC2"),c("PC1","PC2")))

halflife.hum.model.averaging <- function(res.fit, w.matrix, i) {
  average = (c(sapply(res.fit[1,],"[[","OUM")["halflife_hum",][[i]])*(w.matrix["OUM",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMV")["halflife_hum",][[i]])*(w.matrix["OUMV",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMA")["halflife_hum",][[i]])*(w.matrix["OUMA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OUMVA")["halflife_hum",][[i]])*(w.matrix["OUMVA",i]/sum(w.matrix[,i]))) +
    (c(sapply(res.fit[1,],"[[","OU1")["halflife_hum",][[i]])*(w.matrix["OU1",i]/sum(w.matrix[,i])))
  return(average)
} 
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) halflife.hum.model.averaging(res.fit.save, w.matrix, c)),1,mean),nrow=1,dimnames=list(NULL,c("PC1","PC2")))
#st.dev
matrix(apply(sapply(seq(1,ncol(w.matrix)),function(c) halflife.hum.model.averaging(res.fit.save, w.matrix, c)),1,sd),nrow=1,dimnames=list(NULL,c("PC1","PC2")))



OUBM.res <- sapply(sapply(sapply(res.fit,"[[","models"),"[[","OUBM"),"[[","stationary_hum")
station <- data.frame(stationary=unlist(lapply(OUBM.res,function(x) diag(x))),PC=c("PC1","PC2"))
station <- unstack(station,stationary~PC)
apply(station,2,mean)
apply(station,2,sd)

OUBM.res <- sapply(sapply(sapply(res.fit,"[[","models"),"[[","OUMV"),"[[","stationary_hum")
station <- data.frame(stationary=unlist(lapply(OUBM.res,function(x) diag(x))),PC=c("PC1","PC2"))
station <- unstack(station,stationary~PC)
apply(station,2,mean)
apply(station,2,sd)

OUBM.res <- sapply(sapply(sapply(res.fit,"[[","models"),"[[","OUMV"),"[[","stationary_mix")
station <- data.frame(stationary=unlist(lapply(OUBM.res,function(x) diag(x))),PC=c("PC1","PC2"))
station <- unstack(station,stationary~PC)
apply(station,2,mean)
apply(station,2,sd)

sapply(res.fit[1,],"[[","OUMA")["stationary_mix",]

sapply(res.fit[1,],"[[","OUMV")["stationary_mix",]
sapply(res.fit[1,],"[[","OUMV")["sigma_mix",]
sapply(res.fit[1,],"[[","OUMV")["sigma_hum",]
sapply(res.fit[1,],"[[","OUMV")["alpha_mix",]
sapply(res.fit[1,],"[[","OUMV")["alpha_hum",]

sapply(res.fit[1,],"[[","OUMV")[,1]




# end --------------------
